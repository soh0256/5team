package com.springbook.biz.movie;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class MovieSearchVO {
	
	@Getter @Setter
	public String title;
	@Getter @Setter
	public String link;
	@Getter @Setter
	public String image;
	@Getter @Setter
	public String subtitle;
	@Getter @Setter
	public String pubDate;
	@Getter @Setter
	public String director;
	@Getter @Setter
	public String actor;
	@Getter @Setter
	public float userRating;
	
	@Override
	public String toString() {
        return "Movie [title=" + title + ", link=" + link + ", image=" + image + ", subtitle=" + subtitle + ", pubDate=" + pubDate
                + ", director=" + director + ", actor=" + actor + ", userRating=" + userRating  + "]";
	}
	
	private List<MovieSearchVO> movieSearch;
	
	public List<MovieSearchVO> getMovieList(){
		return movieSearch;
	}
	
	public void setMovieVOList(List<MovieSearchVO> movieSearch) {
		this.movieSearch = movieSearch;
	}
	
	
}
