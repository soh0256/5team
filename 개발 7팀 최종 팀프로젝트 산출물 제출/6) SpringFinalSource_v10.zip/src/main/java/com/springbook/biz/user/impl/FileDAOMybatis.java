package com.springbook.biz.user.impl;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbook.biz.user.FileVO;

@Repository("FileDAOMybatis")//이건가?
public class FileDAOMybatis {

	@Autowired
	private SqlSessionTemplate myBatis;
	
	public void insertFile(FileVO vo) {
		System.out.println("FileDAOMybatis의 insertFile 메서드 호출");
		try {
			myBatis.insert("FileDAOMybatis.insertFile", vo);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void updateFile(FileVO vo) {
		System.out.println("FileDAOMybatis의 modifyFile 메서드 호출");
		try {
			myBatis.update("FileDAOMybatis.modifyFile", vo);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public FileVO getFile(String id) {
		System.out.println("FileDAOMybatis의 getFile 메서드 호출");
		return (FileVO) myBatis.selectOne("FileDAOMybatis.getFile", id);
	}
	
	
	public void deleteFile(String id) {
		System.out.println("FileDAOMybatis의 deleteFile 메서드 호출");
		myBatis.delete("FileDAOMybatis.deleteFile",id);
	}
}
