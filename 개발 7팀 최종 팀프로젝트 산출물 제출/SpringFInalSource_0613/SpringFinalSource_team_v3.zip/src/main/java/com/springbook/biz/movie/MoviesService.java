package com.springbook.biz.movie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

@Service
public class MoviesService {

	private static String clientID = "LoTlgXs2Z2EHAxHgEdgO";
	private static String clientSecret = "nrwRFOn6SS";

	// display ==> 몇개 출력
	// start==>몇번쨰부터 (item)
	public List<MovieSearchVO> searchMovie(String keyword, int display, int start) {
		// public List<MovieSearchVO> searchMovie(String keyword, int display, int
		// start){
		List<MovieSearchVO> list = null;
		try {

			URL url;
			url = new URL(
					"https://openapi.naver.com/v1/search/" + "movie.xml?query=" + URLEncoder.encode(keyword, "UTF-8")
							+ (display != 0 ? "&display=" + display : "") + (start != 0 ? "&start=" + start : ""));

			URLConnection urlConn = url.openConnection();
			urlConn.setRequestProperty("X-Naver-Client-Id", clientID);
			urlConn.setRequestProperty("X-Naver-Client-Secret", clientSecret);

			BufferedReader br = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));

			String data = "";
			String msg = null;
			while ((msg = br.readLine()) != null) {
				System.out.println(msg);
				data += msg;
			}

			System.out.println(data);

			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = factory.newPullParser();
			parser.setInput(new StringReader(data));
			// Test에서 했던 방식은 DOM방식이기때문에?

			int eventType = parser.getEventType();
			MovieSearchVO vo = null;
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.END_DOCUMENT: // 문서의 끝
					break;
				case XmlPullParser.START_DOCUMENT:
					list = new ArrayList<MovieSearchVO>();
					break;
				case XmlPullParser.END_TAG: {
					String tag = parser.getName();
					System.out.println(parser.getName());
					if (tag.equals("channel")) {
						list.add(vo);
						return list;
					}
				}

				case XmlPullParser.START_TAG: {
					String tag = parser.getName();
					switch (tag) {
					case "channel":
						vo = new MovieSearchVO();
						break;
					case "title":
						if (vo != null)
							vo.setTitle(parser.nextText());
						System.out.println(vo.getTitle());
						break;
					case "link":
						if (vo != null)
							vo.setLink(parser.nextText());
						System.out.println(vo.getLink());
						break;
					case "image":
						if (vo != null)
							vo.setImage(parser.nextText());
						System.out.println(vo.getImage());
						break;
					case "subtitle":
						if (vo != null)
							vo.setSubtitle(parser.nextText());
						System.out.println(vo.getSubtitle());
						break;
					case "pubDate":
						if (vo != null)
							vo.setPubDate(parser.nextText());
						System.out.println(vo.getPubDate());
						break;
					case "director;":
						if (vo != null)
							vo.setDirector(parser.nextText());
						System.out.println(vo.getDirector());
						break;
					case "actor":
						if (vo != null)
							vo.setActor(parser.nextText());
						System.out.println(vo.getActor());
						break;
					case "userRating":
						if (vo != null)
							vo.setUserRating(parser.next());
						System.out.println(vo.getUserRating());
						break;
					}

				}
				}
				eventType = parser.next();
			}
//			System.out.println(vo);// 여기선 검색된 모든 영화가 출력이 되는데 마지막 list 출력에서는 안됨.

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println(list);// 이미지 제외
		return list;
	}

}
