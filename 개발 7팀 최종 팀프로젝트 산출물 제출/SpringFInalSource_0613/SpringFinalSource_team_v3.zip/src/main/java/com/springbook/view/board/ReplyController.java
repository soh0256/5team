package com.springbook.view.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.reply.ReplyService;
import com.springbook.biz.reply.ReplyVO;

@Controller
@SessionAttributes("reply")  // 어떤 url로 접속해야 ReplyController로 접근할 수 있는지 설정
public class ReplyController {
	@Autowired
	private ReplyService replyService;
	
	// 댓글 등록
	@RequestMapping(value = "/insertReply.do")
	public String insertReply(ReplyVO vo) {
		replyService.insertReply(vo);
		return "redirect:/getBoard.do?board_no=" + vo.getBoard_no();
	}
	
//	@RequestMapping("/replyList.do")
//	public String replyList(ReplyVO vo, Model model) {
//		// Model 정보 저장
//		model.addAttribute("replyList", replyService.replyList(vo));
//		return "getBoardList.jsp"; // View 이름 리턴
//	}

}
