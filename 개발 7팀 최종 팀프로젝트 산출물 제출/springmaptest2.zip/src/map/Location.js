/*global kakao*/
import React, { useEffect } from 'react';

// 글로발 안쓰면 카카오 자체를 못가져옴

const Location=(props)=>{
  useEffect(()=>{
    var container = document.getElementById('map');
    var options = {
      center: new kakao.maps.LatLng(33.450705, 126.570677),
      level: 3//초기위치와 확대값
    };

    //지도에 확대축소바
    var zoomControl = new kakao.maps.ZoomControl();

    var map = new kakao.maps.Map(container, options); // 지도를 생성합니다
// HTML5의 geolocation으로 사용할 수 있는지 확인합니다 
if (navigator.geolocation) {
    // GeoLocation을 이용해서 접속 위치를 얻어옵니다
    navigator.geolocation.getCurrentPosition(function(position) {
        
        var lat = position.coords.latitude, // 위도
            lon = position.coords.longitude; // 경도
            var locPosition = new kakao.maps.LatLng(lat, lon);// 마커가 표시될 위치를 geolocation으로 얻어온 좌표로 생성합니다
            // message = '<div style="padding:5px;">여기에 계신가요?!</div>'; // 인포윈도우에 표시될 내용입니다
            displayMarker(locPosition);
      });
    
} else { // HTML5의 GeoLocation을 사용할 수 없을때 마커 표시 위치와 인포윈도우 내용을 설정합니다
    var locPosition = new kakao.maps.LatLng(33.450701, 126.570667);
    // message = 'geolocation을 사용할수 없어요..';
    displayMarker(locPosition);
}
function displayMarker(locPosition) {
  var marker=new kakao.maps.Marker({
    map:map,
    position:locPosition
  });
  // var iwContent = message; // 인포윈도우에 표시할 내용
      var iwRemoveable = true;

    // 인포윈도우를 생성합니다
    var infowindow = new kakao.maps.InfoWindow({
        // content : iwContent
        removable : iwRemoveable
    });
    // 인포윈도우를 마커위에 표시합니다 
    // infowindow.open(map, marker);
    
    // 지도 중심좌표를 접속위치로 변경합니다
    map.setCenter(locPosition);
}
    map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT);
    // var lat=여기에 data에 있는 x좌표;
    // var lon=여기에 data에 있는 y좌표;
    // var locPosition=new kakao.maps.LatLng(lat,lon);
    // var message=여기에 movie에 있는 상표명과 주소명;
    console.log("array count :"+props.Map_Data.length);

    const movieArray =[];
    for(let i=0; i<props.Map_Data.length;i++){
      movieArray.push({
        content:`<div>${props.Map_Data[i].BIZPLC_NM}</div>`+
        `<div>${props.Map_Data[i].REFINE_ROADNM_ADDR}</div>`+
        `<div>${props.Map_Data[i].REFINE_LOTNO_ADDR}</div>`,
        latlng:new kakao.maps.LatLng(
          props.Map_Data[i].REFINE_WGS84_LAT,
          props.Map_Data[i].REFINE_WGS84_LOGT
        )
      })
    }

    // var positions=[
    //   {
    //     content:'<div>본사</div>',//message대입
    //     latlng:new kakao.maps.LatLng(33.450705,126.570677)//locPostion대입
    //   },
    //   {
    //     content:'<div>연못</div>',
    //     latlng:new kakao.maps.LatLng(33.450936,126.569477)
    //   },
    //   {
    //     content:'<div>텃밭</div>',
    //     latlng:new kakao.maps.LatLng(33.450879,126.569940)
    //   },
    //   {
    //     content:'<div>근린공원</div>',
    //     latlng:new kakao.maps.LatLng(33.451393,126.570738)
    //   }
    // ];
console.log(movieArray.length);
    for(var i=0;i<movieArray.length;i++){
      //마커생산
      var marker = new kakao.maps.Marker({
        map: map,//마커를 표시할 지도
        position:movieArray[i].latlng//마커위치 다넣기
    });

    // 마커에 표시할 인포윈도우를 생성합니다 
    var infowindow = new kakao.maps.InfoWindow({
      content: movieArray[i].content // 인포윈도우에 표시할 내용
  });

    //마커에 마우스 이벤트를 입력
    // 이벤트 리스너로는 클로저를 만들어 등록합니다 
    // for문에서 클로저를 만들어 주지 않으면 마지막 마커에만 이벤트가 등록됩니다
    kakao.maps.event.addListener(marker, 'mouseover', makeOverListener(map, marker, infowindow));
    kakao.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow));
    }
    
    // 인포윈도우를 표시하는 클로저를 만드는 함수입니다 
function makeOverListener(map, marker, infowindow) {
  return function() {
      infowindow.open(map, marker);
  };
}

    // 인포윈도우를 닫는 클로저를 만드는 함수입니다 
function makeOutListener(infowindow) {
  return function() {
      infowindow.close();
  };
}
    }, [])

    return (
        <div>
          <div id="map" style={{width:"100%", height:"350px"}}></div>
        </div>
    )
}

export default Location;