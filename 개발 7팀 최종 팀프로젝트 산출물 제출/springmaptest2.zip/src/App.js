/*global kakao*/
import React,{useEffect} from "react";
import "./App.css";
import Movie from "./Movie";
import axios from "axios";
import Location from './map/Location';

class App extends React.Component {
    state = {
        data: {},
    };

    getMovie() {

        const API_KEY = "49b8197f431545a8b04abeea3b7b820f";
        const url = `https://openapi.gg.go.kr/MovieTheater?Type=json&Key=${API_KEY}`;
        //json형태로받아옴(기본이 xml이라)
        console.log(url);
        axios.get(url).then((response) => {
            const data = response.data.MovieTheater[1].row;
            console.log(data[0]);

            this.setState({
                data: data,
            });
        });
    }
    componentDidMount() {
        this.getMovie();
    }

    render() {
        const { data } = this.state;

        return (
            <div>
                <div>
                <Location Map_Data={data} />
                </div>

                <div>
                <Movie
                            BIZPLC_NM={data.BIZPLC_NM}//사업장명
                            REFINE_ROADNM_ADDR={data.REFINE_ROADNM_ADDR}//소재지도로명주소
                            REFINE_LOTNO_ADDR={data.REFINE_LOTNO_ADDR}//소재지지번주소
                            REFINE_WGS84_LAT={data.REFINE_WGS84_LAT}//위도
                            REFINE_WGS84_LOGT={data.REFINE_WGS84_LOGT}//경도
                            />
                </div>
            </div>
        );
    }
}
//https://data.gg.go.kr/portal/data/service/selectServicePage.do?page=1&rows=10&sortColumn=&sortDirection=&infId=W4X5359M8398463DP26M1395912&infSeq=3&order=&loc=&searchWord=%EC%98%81%ED%99%94&BIZPLC_NM=&REFINE_ROADNM_ADDR=
//참고사이트(컬럼값)
//https://kevink1113.tistory.com/entry/React-JS-%EA%B3%B5%EA%B3%B5%EB%8D%B0%EC%9D%B4%ED%84%B0%ED%8F%AC%ED%84%B8-%EB%AF%B8%EC%84%B8%EB%A8%BC%EC%A7%80-API-%ED%95%9C%EA%B5%AD%ED%99%98%EA%B2%BD%EA%B3%B5%EB%8B%A8-%EB%8C%80%EA%B8%B0%EC%98%A4%EC%97%BC%EC%A0%95%EB%B3%B4%EC%9D%B4%EC%9A%A9%ED%95%98%EA%B8%B0
//api사용방법
export default App;