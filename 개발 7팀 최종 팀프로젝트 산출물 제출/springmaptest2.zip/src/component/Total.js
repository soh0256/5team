/*global kakao*/
import axios from "axios";
import { useEffect, useState } from "react";
import Movie from "../Movie"

const {kakao}=window;
function Total(){

  const [BIZPLC,setBIZPLC]=useState("");
  const [ROADNM_ADDR,setROADNM_ADDR]=useState("");
  const [LOTNO_ADDR,setLOTNO_ADDR]=useState("");

useEffect(()=>{

  axios.get('https://openapi.gg.go.kr/MovieTheater?Type=json&Key=49b8197f431545a8b04abeea3b7b820f')
  .then((res)=>{
    const movieDataList=res.data.MovieTheater[1].row;
    console.log(movieDataList);
    drowmap(movieDataList);
  })
  .catch((err)=>{
alert(err.response.data.msg);
  });

},[])

function drowmap(movieDataList){
if(navigator.geolocation){
  navigator.geolocation.getCurrentPosition(function(myposition){
    const container=document.getElementById("kakaomap");
    const options={
      center:new kakao.maps.LatLng(myposition.coords.latitude,myposition.coords.longitude),
      level:3
    }
    const map=new kakao.maps.Map(container,options);
    const loc=new kakao.maps.LatLng(myposition.coords.latitude,myposition.coords.longitude);
    mypositionMarker(loc,map);
    movietheat(movieDataList,map);
  });
}
}

function mypositionMarker(myloc,map){
const mylocmarker=new kakao.maps.Marker({
map:map,
position:myloc
});
}

function movietheat(movieDataList,map){
for(let i=0;i<movieDataList.length;i++){
  const latlng=new kakao.maps.LatLng(movieDataList[i].REFINE_WGS84_LAT,movieDataList[i].REFINE_WGS84_LOGT);

  const moviemarker=new kakao.maps.Marker({
    map:map,
    position:latlng
  });

  kakao.maps.event.addListener(moviemarker,"click",function(){
    setBIZPLC(movieDataList[i].BIZPLC_NM);
    setROADNM_ADDR(movieDataList[i].REFINE_ROADNM_ADDR);
    setLOTNO_ADDR(movieDataList[i].REFINE_LOTNO_ADDR);
  });
}
}

return(
  <div>
    <div id="kakaomap" style={{width:"700px", height:"700px"}}></div>
    <Movie BIZPLC_NM={BIZPLC} REFINE_ROADNM_ADDR={ROADNM_ADDR} REFINE_LOTNO_ADDR={LOTNO_ADDR} />
  </div>
)
}
export default Total;