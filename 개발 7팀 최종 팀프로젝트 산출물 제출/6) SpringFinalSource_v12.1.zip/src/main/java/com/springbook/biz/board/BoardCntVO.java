package com.springbook.biz.board;

import lombok.Getter;
import lombok.Setter;

//VO(Value Object)
@Getter @Setter
public class BoardCntVO {
	private String board_cnt_no; // ��ȣ
	private String id;			// �����ڵ�
	private String board_no;	// �Խñ� ��ȣ
	private Number gcnt;		// ���ƿ�
	private Number bcnt;		// �Ⱦ��
	
	@Override
	public String toString() {
		return "CntVO [id=" + id + ", board_no=" 
				+ board_no + ", gcnt=" + gcnt + ", bcnt=" + bcnt + "]";
	}


}