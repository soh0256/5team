# React Moive App with Nomad Coders

### 🔔 목표
- **React 기초 개념 공부**
- **네이버 오픈 API 사용해서 영화 검색**


### 🔔 화면 
**초기 화면**
![image](https://user-images.githubusercontent.com/59307414/90318684-27c6f100-df6d-11ea-99be-964c0a13f9fd.png)

**검색**
![image](https://user-images.githubusercontent.com/59307414/90318692-331a1c80-df6d-11ea-81ba-180d4df3a68e.png)
포스터 및 배우 클릭 시 네이버 검색 창으로 이동
