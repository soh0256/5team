import React from 'react';
import { BrowserRouter, Route } from "react-router-dom";
import Home from "./routes/Home";
import Navigation from "./components/Navigation";
import Total from "./components/Total"

function App() {
  return <BrowserRouter>
    <Navigation />
    <Route path="/" exact={true} component={Home} />
    <Route path="/location" exact={true} component={Total} />
  </BrowserRouter>;
}

export default App;
