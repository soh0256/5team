/*global kakao*/
import axios from "axios";
import React,{ useEffect, useState } from "react";
import Movie from "../routes/MovieTheat"

const {kakao}=window;
function Total(){

  const [BIZPLC,setBIZPLC]=useState("");
  const [ROADNM_ADDR,setROADNM_ADDR]=useState("");
  const [LOTNO_ADDR,setLOTNO_ADDR]=useState("");

useEffect(()=>{

  axios.get('https://openapi.gg.go.kr/MovieTheater?Type=json&pSize=1000&Key=49b8197f431545a8b04abeea3b7b820f')
  .then((res)=>{
    // console.log(res);//영화관목록어디서 받아오는지 확인용
    const movieDataList=res.data.MovieTheater[1].row;
    drowmap(movieDataList);
  })
  .catch((err)=>{
alert(err.response.data.msg);
  });

},[])

function drowmap(movieDataList){
if(navigator.geolocation){
  navigator.geolocation.getCurrentPosition(function(myposition){
    const container=document.getElementById("kakaomap");
    const options={
      center:new kakao.maps.LatLng(myposition.coords.latitude,
        myposition.coords.longitude),
      level:3
    }
    const map=new kakao.maps.Map(container,options);
    const maptyper=new kakao.maps.MapTypeControl();
    const loc=new kakao.maps.LatLng(myposition.coords.latitude,
      myposition.coords.longitude);
    const zoombar=new kakao.maps.ZoomControl();
    const mycontent='<div style="padding:5px;">현재 위치</div>';
    // mypositionMarker(loc,map); 마커표시
    movietheat(movieDataList,map);
    myinfowindow(loc,map,mycontent);
    map.addControl(maptyper,kakao.maps.ControlPosition.TOPRIGHT);
    map.addControl(zoombar,kakao.maps.ControlPosition.RIGHT);
  });
}
}

// function mypositionMarker(myloc,map){
// const mylocmarker=new kakao.maps.Marker({
// map:map,
// position:myloc,
// });
// }

function myinfowindow(myloc,map,mycontent){
const infowindow=new kakao.maps.InfoWindow({
map:map,
position:myloc,
content:mycontent
});
console.log(infowindow);
}

function movietheat(movieDataList,map){
for(let i=0;i<movieDataList.length;i++){
  const latlng=new kakao.maps.LatLng(movieDataList[i]
    .REFINE_WGS84_LAT,movieDataList[i].REFINE_WGS84_LOGT);

  const moviemarker=new kakao.maps.Marker({
    map:map,
    position:latlng
  });

  kakao.maps.event.addListener(moviemarker,"click",function(){
    setBIZPLC(movieDataList[i].BIZPLC_NM);
    setROADNM_ADDR(movieDataList[i].REFINE_ROADNM_ADDR);
    setLOTNO_ADDR(movieDataList[i].REFINE_LOTNO_ADDR);
  });
}
}

return(
  <div>
    <div id="kakaomap" style={{width:"700px", height:"700px"}}></div>
    <Movie BIZPLC_NM={BIZPLC} REFINE_ROADNM_ADDR={ROADNM_ADDR} REFINE_LOTNO_ADDR={LOTNO_ADDR} />
  </div>
)
}
export default Total;