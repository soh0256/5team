package com.springbook.view.board;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.springbook.biz.board.BoardCntVO;
import com.springbook.biz.board.BoardListVO;
import com.springbook.biz.board.BoardService;
import com.springbook.biz.board.BoardVO;
import com.springbook.biz.pagination.Pagination;
import com.springbook.biz.reply.ReplyService;
import com.springbook.biz.reply.ReplyVO;

@Controller
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	@Autowired
	private ReplyService replyService;

	@RequestMapping("/dataTransform.do")
	@ResponseBody
	public BoardListVO dataTransform(BoardVO vo) {
		vo.setSearchCondition("TITLE");
		vo.setSearchKeyword("");
		List<BoardVO> boardList = boardService.getBoardList(vo);
		BoardListVO boardListVO = new BoardListVO();
		boardListVO.setBoardList(boardList);
		return boardListVO;
	}
	
	// 영화 검색 후, 클릭시 리뷰 쓰기 화면으로 넘어가며 영화 이름은 자동으로 가져오려고 생성
	@RequestMapping("/insertMovie.do")
	public String replyUpdateView(Model mv, @RequestParam("title")String title) throws Exception {
		try {
			mv.addAttribute("title", title); // 쿼리스트링에 title(영화제목) mv에 넣어서 jsp파일에 보냄
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "insertBoard.jsp";
	}

	// 글 등록
	@RequestMapping(value = "/insertBoard.do")
	public String insertBoard(BoardVO vo) throws IOException {
		// 파일 업로드 처리
		MultipartFile uploadFile = vo.getUploadFile();
		if (!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			uploadFile.transferTo(new File("D:/" + fileName));
		}

		boardService.insertBoard(vo);
		return "getBoardList.do";
	}

	// 글 수정
	@RequestMapping("/updateBoard.do")
	public String updateBoard(@ModelAttribute("board") BoardVO vo) {
		boardService.updateBoard(vo);
		return "getBoardList.do";
	}

	// 글 삭제
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(BoardVO vo) {
		boardService.deleteBoard(vo);
		return "getBoardList.do";
	}

	// 글 상세 조회
	@RequestMapping("/getBoard.do")
	public String getBoard(BoardVO vo, Model model, @RequestParam("board_no")int board_no, ReplyVO rvo) {
		model.addAttribute("board", boardService.getBoard(vo)); // Model 정보 저장
		
		List<ReplyVO> replyList = replyService.replyList(board_no);
		model.addAttribute("replyList", replyList);
		
		rvo = new ReplyVO();
		rvo.getUser_reply();
		model.addAttribute("user_reply", rvo);
		
		boardService.viewCount(vo);	// 글 조회시 조회수 sql문 실행
		return "getBoard.jsp"; //// View 이름 리턴
	}

	// 검색 조건 목록 설정
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new HashMap<String, String>();
		conditionMap.put("제목", "BOARD_TITLE");
		conditionMap.put("내용", "BOARD_CONTENTS");
		return conditionMap;
	}

	// 글 목록 검색
	@RequestMapping("/getBoardList.do")
	public String getBoardList(@ModelAttribute("boardVO")BoardVO vo, @RequestParam(defaultValue ="1") int curPage , Model model)throws Exception {
		
		//전체 리스트 개수 
		int listCnt = boardService.selectBoardListCnt(vo);
		
		Pagination pagination = new Pagination(listCnt, curPage);
		
		vo.setStartIndex(pagination.getStartIndex());
		vo.setCntPerPage(pagination.getPageSize());
		
		if (vo.getSearchCondition() == null)
			vo.setSearchCondition("BOARD_TITLE");
		if (vo.getSearchKeyword() == null)
			vo.setSearchKeyword("");
		
		model.addAttribute("lisCnt", listCnt);
		model.addAttribute("boardList", boardService.getBoardList(vo));
		model.addAttribute("pagination", pagination);
		return "getBoardList.jsp"; // Model 정보 저장
	}
	
	// 게시글 좋아요
	@ResponseBody
	@RequestMapping(value = "/insertBoardCnt.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String insertBoardCnt(BoardCntVO vo, HttpServletRequest request, HttpServletResponse response) throws IOException {
			
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
			
		int BcntCount = boardService.selectBoardCnt(vo);
		if(BcntCount == Integer.parseInt("1")) {
			boardService.downBoardBcnt(vo);
		}
			
		// 회원이 해당 게시글에 좋아요 버튼을 누른적이 없는 경우 insert문으로 칼럼 생성 / count로 0이면 칼럼이 없으니 실행
		int GcntCount = boardService.selectBoardCnt(vo);
		if(GcntCount == Integer.parseInt("0")) {
			boardService.insertBoardCnt(vo);
		}
			
		// 위에서 insert문 생성 후, board_gcnt값이 0이라면 좋아요 수 증가
		// board_gcnt값이 1이라면 좋아요 버튼을 두번 눌렀다고 판단하고(좋아요 취소를 하려고) 해당 칼럼 삭제
		// 다시 좋아요 버튼을 누르려 한다면 위에 insert문 실행
		int Gcnt = boardService.saveBoardCnt(vo);
		if(Gcnt == Integer.parseInt("0")){
			boardService.updateBoardCnt(vo);
		}else{
			boardService.deleteBoardCnt(vo);
		}
			
		// JSON형식으로 입력
		// JSONObject 사용하려면 pom.xml에 추가해야함
		JSONObject obj = new JSONObject();
		try {
		obj.put("Gcnt", Gcnt);
		obj.put("BcntCount", BcntCount);
		}catch(Exception e) {
			e.printStackTrace();
		}
		response.getWriter().write(obj.toString());
			
		return null;
	}
		
	// 게시글 싫어요
	@ResponseBody
	@RequestMapping(value = "/insertBoardBcnt.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String insertBoardBcnt(BoardCntVO vo, HttpServletRequest request, HttpServletResponse response) throws IOException {
				
		request.setCharacterEncoding("utf-8");
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
			
		int GcntCount = boardService.selectBoardCnt(vo);
		if(GcntCount == Integer.parseInt("1")) {
			boardService.downBoardCnt(vo);
		}
			
		int BcntCount = boardService.selectBoardCnt(vo);
		if(BcntCount == Integer.parseInt("0")) {
			boardService.insertBoardBcnt(vo);
		}
		
		int Bcnt = boardService.saveBoardBcnt(vo);
		if(Bcnt == Integer.parseInt("0")){
			boardService.updateBoardBcnt(vo);
		}else{
			boardService.deleteBoardBcnt(vo);
		}
			
		JSONObject obj = new JSONObject();
		try {
		obj.put("Bcnt", Bcnt);
		obj.put("GcntCount", GcntCount);
		}catch(Exception e) {
			e.printStackTrace();
		}
		response.getWriter().write(obj.toString());
			
		return null;
	}
		
	// 좋아요 싫어요 합계 구함
	@RequestMapping(value = "/Count.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String Count(HttpServletRequest request, HttpServletResponse response) throws IOException {
			
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
			
		int board_no = Integer.parseInt(request.getParameter("board_no"));
			
		int GcntCnt = boardService.sumBoardCnt(board_no);
		int BcntCnt = boardService.sumBoardBcnt(board_no);
			
		out.println(GcntCnt);
		out.println(BcntCnt);
		out.close();
			
		return null;
	}
}
