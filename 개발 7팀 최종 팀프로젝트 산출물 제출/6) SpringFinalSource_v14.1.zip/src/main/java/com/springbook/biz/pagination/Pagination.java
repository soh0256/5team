package com.springbook.biz.pagination;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Pagination {
	
	/*한 페이지당 게시글 수*/
	private int pageSize = 10;
	
	/*한 블럭(range)당 페이지 수*/
	private int rangeSize = 10;
	
	/*현재 페이지*/
	private int curPage = 1;
	
	/*현재 블럭(range)*/
	private int curRange = 1;
	
	/*총 게시글 수*/
	private int listCnt;
	
	/*총 페이지 수*/
	private int pageCnt;
	
	/*총 블럭(range) 수*/
	private int rangeCnt;
	
	/*시작 페이지*/
	private int startPage = 1;
	
	/*끝 페이지*/
	private int endPage = 1;
	
	/*시작 index*/
	private int startIndex = 0;
	
	/*이전 페이지*/
	private int prevPage;
	
	/*다음 페이지*/
	private int nextPage;
	
	public Pagination(int listCnt, int curPage) {
		setCurPage(curPage); //현재 페이지
		setListCnt(listCnt); //총 게시물 수
		setPageCnt(listCnt);
		setRangeCnt(curPage);
		rangeSetting(curPage);
		setStartIndex(curPage);
		
	}
	
	// 총 게시글 수/한 페이지당 게시글 수 =필요한 총 페이지 수
	public void setPageCnt(int listCnt) {
		this.pageCnt = (int) Math.ceil(listCnt*1.0/pageSize);
	}
	
	// 필요한 총 페이지 수/한 블럭당 페이지 수 = 총 블럭 수 
	public void setRangeCnt(int pageCnt) {
		this.rangeCnt = (int) Math.ceil(pageCnt*1.0/rangeSize);
	}
	
	//curRange 현재 블럭
	public void rangeSetting(int curPage) {
		setCurRange(curPage); 
		//현재시작페이지=(현재블럭-1)*한블럭당페이지수 + 1 =
		//1 = (1-1)*10 + 1 = 1
		//11 = (2-1)*10 + 1 = 
		this.startPage = (curRange -1)*rangeSize + 1;
		this.endPage = startPage + rangeSize - 1;
		
		if(endPage > pageCnt) {
			this.endPage = pageCnt;
		}
		
		this.prevPage = curPage - 1; //이전 페이지 설정
		this.nextPage = curPage + 1; //다음 페이지 설정
	}

	public void setCurRange(int curPage) {
		//현재 범위 = ((현재 페이지-1)/한블럭당페이지수)  + 1
		// 1 = (1-1)/10 + 1
		// 1 = (2-1)/10 + 1 = 1.1 = 1
		this.curRange = (int)((curPage-1)/rangeSize) + 1;
	}
	
	public void setStartIndex(int curPage) {
		this.startIndex = (curPage - 1)*pageSize;
		// 1-1*10개 = 0 ==> 현재페이지 1일 때
		// 2-1*10개 = 1 ==> 현재페이지 2
	}
	
	
	
}
