package com.springbook.biz.reply.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.reply.ReplyService;
import com.springbook.biz.reply.ReplyVO;

@Service("replyService")
public class ReplyServiceImpl implements ReplyService {
	@Autowired
	private ReplyDAOMybatis replyDAO;

	@Override
	public void insertReply(ReplyVO vo) {
		replyDAO.insertReply(vo);
	}

	@Override
	public List<ReplyVO> replyList(int board_no) {
		return replyDAO.selectReply(board_no);
	}

	@Override
	public void updateReply(ReplyVO vo) {
		replyDAO.updateReply(vo);
	}

	@Override
	public void deleteReply(int rno) {
		replyDAO.deleteReply(rno);
	}

	@Override
	public String getReply(ReplyVO vo) {
		replyDAO.getReply(vo);
		return null;
	}
}