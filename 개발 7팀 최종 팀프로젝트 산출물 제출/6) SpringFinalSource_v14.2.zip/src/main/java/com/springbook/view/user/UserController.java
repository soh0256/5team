package com.springbook.view.user;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import javax.swing.JOptionPane;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springbook.biz.board.BoardService;
import com.springbook.biz.common.Constants;
import com.springbook.biz.notice.NoticeService;
import com.springbook.biz.user.FileVO;
import com.springbook.biz.user.UserService;
import com.springbook.biz.user.UserVO;
import com.springbook.biz.user.impl.UserDAO;

import sun.print.resources.serviceui;

@Controller
@Resource(name="userService")
@SessionAttributes("user")
public class UserController implements HttpSessionListener{//드디어 사진오류의 원인? 인터페이스 구현인가..?

	@Autowired//반드시 써주어야 객체 주입됨, 중요
	private UserService userService;//널값의 원인일까 드디어
	
	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value = "/signUpChoose.do", method = RequestMethod.GET)
	public String signUpChooseView() {
		System.out.println("회원가입 선택");
		return "signUpChoose.jsp";
	}
	
	// 회원가입
	@RequestMapping(value = "/signUp.do", method = RequestMethod.GET)
	public String signUpView(UserVO vo) {

		System.out.println("회원가입 화면으로 이동");
			
		return "signUp.jsp";
	}
	
	@RequestMapping(value = "/signUpCorp.do", method = RequestMethod.GET)
	public String signUpCorpView(UserVO vo) {

		System.out.println("회원가입 화면으로 이동");
			
		return "signUpCorp.jsp";
	}
	
		
	// HttpSession객체를 매개변수로 받음
	@RequestMapping(value = "/signUp.do", method = RequestMethod.POST)
	public String signUp(@RequestParam("userImageAttachFile") MultipartFile file, HttpServletRequest request,HttpSession session, Model model, UserVO vo) throws IOException{

		System.out.println("UserController의 signUp 호출");

			
		if(vo.getId() == null || vo.getId().equals("")) { 
			throw new IllegalArgumentException("아이디는 반드시 입력해야 합니다."); 
		}else if(vo.getPw() == null || vo.getPw().equals("")) { 
			throw new IllegalArgumentException("비밀번호는 반드시 입력해야 합니다."); 
		}else if(vo.getName() == null || vo.getName().equals("")) { 
			throw new IllegalArgumentException("이름은 반드시 입력해야 합니다."); 
		}
		
		try {

			String address = vo.getAddress() + vo.getDetail_address() + vo.getExtra_address();
			vo.setAddress(address);
			vo.setGrade("User");
			
			System.out.println(vo.getName());
			userService.insertUser(file ,vo);
			
			//업로드된 실제 파일명
			String originFileName = file.getOriginalFilename();
			
			//업로드된 실제 파일의 확장자
			String originFileExt = originFileName.substring(originFileName.lastIndexOf(".")+1);
			
			//db와 로컬저장소에 저장될 파일이름 만들기
			String fileName = UUID.randomUUID().toString() + "." + originFileExt;
			
			//로컬저장소에 파일이 저장될 경로 ==> constant로 관리 ==> D:/FinalLevelUp
			String savePath = request.getSession().getServletContext().getRealPath("/resources/userImage/");
			System.out.println(request.getSession().getServletContext().getContextPath());
			
			//위의 경로 저장시, 폴더 생성이 되어있지 않다면 만들어 줌
			if(!new File(savePath).exists()) {
				try {
					new File(savePath).mkdir();
				}catch (Exception e) {
					e.getStackTrace();
				}
			}
			
			//풀 경로 
			String filePath = savePath + File.separator + fileName;
			
			//업로드 된 파일을 풀 경로에 복사
			file.transferTo(new File(filePath));
			
			//업로드된 파일 정보를 user_file 테이블어 넣어주기 
			FileVO fileVO = new FileVO();
			fileVO.setId(vo.getId());
			System.out.println(vo.getId());
			fileVO.setOrigin_file_name(originFileName);
			System.out.println(originFileName);
			fileVO.setFile_name(fileName);
			System.out.println(fileName);
			fileVO.setFile_path(filePath);
			System.out.println(filePath);
			
			userService.insertFile(fileVO);
		} catch (Exception e) {
			e.printStackTrace();
		}//널값의 원인일까 드디어(userDao.insertUser가 아니라)

	
		return "index.jsp";
		
	}
	@RequestMapping(value = "/signUpCorp.do", method = RequestMethod.POST)
	public String signUpCorp(@RequestParam("userImageAttachFile") MultipartFile file, HttpServletRequest request, HttpSession session, Model model, UserVO vo) throws IOException{
		
		System.out.println("UserController의 signUpCorp 호출");
		
		
		
		
		if(vo.getId() == null || vo.getId().equals("")) { 
			throw new IllegalArgumentException("아이디는 반드시 입력해야 합니다."); 
		}else if(vo.getPw() == null || vo.getPw().equals("")) { 
			throw new IllegalArgumentException("비밀번호는 반드시 입력해야 합니다."); 
		}else if(vo.getName() == null || vo.getName().equals("")) { 
			throw new IllegalArgumentException("이름은 반드시 입력해야 합니다."); 
		}
		
		try {
			
			String address = vo.getAddress() + vo.getDetail_address() + vo.getExtra_address();
			vo.setAddress(address);
			vo.setGrade("Corp");
			
			userService.insertUser(file ,vo);
			
			//업로드된 실제 파일명
			String originFileName = file.getOriginalFilename();
			
			//업로드된 실제 파일의 확장자
			String originFileExt = originFileName.substring(originFileName.lastIndexOf(".")+1);
			
			//db와 로컬저장소에 저장될 파일이름 만들기
			String fileName = UUID.randomUUID().toString() + "." + originFileExt;
			
			//로컬저장소에 파일이 저장될 경로 ==> constant로 관리 ==> D:/FinalLevelUp
			String savePath = request.getSession().getServletContext().getRealPath("/resources/userImage/");
			
			//위의 경로 저장시, 폴더 생성이 되어있지 않다면 만들어 줌
			if(!new File(savePath).exists()) {
				try {
					new File(savePath).mkdir();
				}catch (Exception e) {
					e.getStackTrace();
				}
			}
			
			//풀 경로 
			String filePath = savePath + File.separator + originFileExt;
			
			//업로드 된 파일을 풀 경로에 복사
			file.transferTo(new File(filePath));
			
			//업로드된 파일 정보를 user_file 테이블어 넣어주기 
			FileVO fileVO = new FileVO();
			fileVO.setId(vo.getId());
			System.out.println(vo.getId());
			fileVO.setOrigin_file_name(originFileName);
			System.out.println(originFileName);
			fileVO.setFile_name(fileName);
			System.out.println(fileName);
			fileVO.setFile_path(filePath);
			System.out.println(filePath);
			
			userService.insertFile(fileVO);
		} catch (Exception e) {
			e.printStackTrace();
		}//널값의 원인일까 드디어(userDao.insertUser가 아니라)
		
		
		return "index.jsp";
		
	}
	
	@RequestMapping(value="/login.do", method = RequestMethod.GET)
	public String loginView(HttpServletRequest request, HttpSession session, Model model)throws Exception {
		return "index.jsp";
	}
	
	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public String loginAction(@ModelAttribute("userVO")UserVO vo, HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) throws Exception {
		try {
			UserVO user = userService.getUser(vo);
			session.setAttribute("user", user);//한 데이터를 담는게 아니라 전체를 담는다.
			// 공지사항 권한 나누기 위해 "userGrad"에 로그인하는 대상의 권한 저장
			session.setAttribute("userGrad", user.getGrade());
			if(user!=null) 
			return "menu.do";
		}catch(Exception e) {
			e.printStackTrace();
			return "index.jsp";
		} 
		
		return "user";
		
	}
	
	
	@RequestMapping(value = "/menu.do", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView menuView(@ModelAttribute("userVO")UserVO vo, HttpServletRequest request, HttpSession session) {
		session.setAttribute("user", vo);
		System.out.println("메뉴화면으로 이동");
		
		ModelAndView mv = new ModelAndView();
		
		Map<String, String> menuParam = new HashMap<String, String>();
	
		List<Map<String, String>> noticeList = null;
		List<Map<String, String>> boardList = null;
	
		noticeList = noticeService.noticeList(menuParam);
		boardList = boardService.boardList(menuParam);
	
		mv.addObject("noticeList", noticeList);
		mv.addObject("boardList", boardList);
		mv.setViewName("menu.jsp");
		
		return mv;
		
	}
	
	@RequestMapping(value = "/myPage.do", method = RequestMethod.GET)
	public String myPageView(@ModelAttribute("userVO")UserVO vo, FileVO filevo, HttpSession session) {
		try {
			
			System.out.println("마이페이지 화면으로 이동");
			UserVO userVO = new UserVO();
			userVO = (UserVO) session.getAttribute("user");
			
			FileVO fileVO = new FileVO();
			fileVO = userService.getFile(userVO.getId());
			
			System.out.println(fileVO.getFile_path());

			session.setAttribute("userFile", fileVO);
			
		} catch(Exception e) {
			
			e.printStackTrace();
			
		}
			
		return "myPage.jsp";
			
	}
	
	
	@RequestMapping(value="/updateUser.do", method=RequestMethod.GET)
	public String updateView(UserVO vo, HttpSession session) throws Exception {
		
		System.out.println("수정화면으로 이동");
		UserVO userVO = new UserVO();
		userVO = (UserVO) session.getAttribute("user");
		
		session.setAttribute("userFile",userService.getFile(userVO.getId()));
		
		return "updateUser.jsp";
	}

	@RequestMapping(value = "/updateUser.do", method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("userVO")UserVO vo, @RequestParam("userImageAttachFile")MultipartFile file, HttpSession session) throws IOException{
			
		System.out.println("UserController의 updateUser호출");
		
		try {
			
			System.out.println("수정화면으로 이동");
			UserVO userVO = new UserVO();
			userVO = (UserVO) session.getAttribute("user");
			
			session.setAttribute("userFile", userService.getFile(userVO.getId()));
			
			String address = vo.getAddress() + vo.getDetail_address() + vo.getExtra_address();
			vo.setAddress(address);
			
			System.out.println(vo.getAddress() + vo.getPost_num());//여기까지는 정상적으로 작동
			
			
			userService.modifyUser(file, vo);
			
			//업로드된 실제 파일명
			String originFileName = file.getOriginalFilename();
			
			//업로드된 실제 파일의 확장자
			String originFileExt = originFileName.substring(originFileName.lastIndexOf(".")+1);
			
			//db와 로컬저장소에 저장될 파일이름 만들기
			String fileName = UUID.randomUUID().toString() + "." + originFileExt;
			
			//로컬저장소에 파일이 저장될 경로 ==> constant로 관리 ==> D:/FinalLevelUp
			String savePath = Constants.getUploadImagesPath();
			
			//위의 경로 저장시, 폴더 생성이 되어있지 않다면 만들어 줌
			if(!new File(savePath).exists()) {
				try {
					new File(savePath).mkdir();
				}catch (Exception e) {
					e.getStackTrace();
				}
			}
			
			//풀 경로 
			String filePath = savePath + File.separator + fileName;
			
			//업로드 된 파일을 풀 경로에 복사
			file.transferTo(new File(filePath));
			
			//업로드된 파일 정보를 user_file 테이블어 넣어주기 
			FileVO fileVO = new FileVO();
			fileVO.setId(vo.getId());
			System.out.println(vo.getId());
			fileVO.setOrigin_file_name(originFileName);
			System.out.println(originFileName);
			fileVO.setFile_name(fileName);
			System.out.println(fileName);
			fileVO.setFile_path(filePath);
			System.out.println(filePath);
			
			userService.modifyFile(fileVO);
			
			
		} catch(Exception e) {
			
			e.printStackTrace();
			
		}
			
		return "updateUser.jsp";
			
	}
	
	//HttpSession 객체를 매개변수로 받음
	@RequestMapping(value = "/delete.do", method = RequestMethod.POST)
	public String delete(UserVO vo, UserDAO userDAO) {
		System.out.println("회원 삭제 처리");
			
		userService.deleteFile(vo.getId());
		userService.deleteUser(vo);
			
		return "index.jsp";
			
	}
	
	@RequestMapping(value = "/find.do", method = RequestMethod.GET)
	public String findUser() {
		return "findID.jsp";
	}
	
	@RequestMapping(value = "/find_id.do", method = RequestMethod.POST)
	public String findid(UserVO vo, UserDAO userdao, Model model) {
		userService.findId(vo);
		UserVO userfindId = userService.findId(vo);
		if(userfindId==null) {
			try {
				JOptionPane.showMessageDialog(null, "해당값은 찾을수 없습니다.");
				return "findID.jsp";
			}catch (Exception e) {
			}
		}
		model.addAttribute("UserId", userfindId.getId());
		return "findID.jsp";
	}
	
	@RequestMapping(value = "/find_pw.do", method = RequestMethod.POST)
	public String findpw(UserVO vo, UserDAO userdao, Model model) {
		userService.findPw(vo);
		UserVO userfindPw=userService.findPw(vo);
		if(userfindPw==null) {
			try {
				JOptionPane.showMessageDialog(null, "해당값은 찾을수 없습니다.");
				return "findID.jsp";
			}catch (Exception e) {
			}
		}
		model.addAttribute("UserPw", userfindPw.getPw());
		return "findID.jsp";
	}
	
	
	@RequestMapping(value="location.do")
	public String searchLoc(UserVO vo) {
		return "location.jsp";
	}
	
	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		HttpSession session = arg0.getSession();
		session.removeAttribute("id");
		session.invalidate();
	}
		
	
	

}
