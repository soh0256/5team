package com.springbook.view.board;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.springbook.biz.reply.ReplyService;
import com.springbook.biz.reply.ReplyVO;

@Controller
@SessionAttributes("reply") // 어떤 url로 접속해야 ReplyController로 접근할 수 있는지 설정
public class ReplyController {
	@Autowired
	private ReplyService replyService;

	// 댓글 등록
	@RequestMapping(value = "/insertReply.do")
	public String insertReply(ReplyVO vo) {
		replyService.insertReply(vo);
		return "redirect:/getBoard.do?board_no=" + vo.getBoard_no();
	}

//	@RequestMapping("/replyList.do")
//	public String replyList(ReplyVO vo, Model model) {
//		// Model 정보 저장
//		model.addAttribute("replyList", replyService.replyList(vo));
//		return "getBoardList.jsp"; // View 이름 리턴
//	}

	// 댓글 삭제 POST
	@RequestMapping(value = "/replyDelete.do")
	// 응답 값을 보낼때 상대 데이터에 값을 넣어줌 / 매개변수를 받는건 request
	@ResponseBody
	public String replyDelete(HttpServletRequest request) throws Exception {
		try {
			ReplyVO vo = new ReplyVO();
			vo.setBoard_no(request.getParameter("board_no"));
			vo.setUser_reply_no(Integer.parseInt(request.getParameter("user_reply_no")));
			replyService.deleteReply(vo.getUser_reply_no());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Y";
		// return에 Y를 줬을때 reload 되게 확인
	}

	@RequestMapping(value = "/replyUpdateView.do", method = RequestMethod.GET)
	public String replyUpdateView(ReplyVO vo, HttpServletRequest req, Model mv, @RequestParam (value = "user_reply_no", required = false)int user_reply_no) throws Exception {
		try {
			System.out.println("user_reply_no : " + user_reply_no);
			mv.addAttribute("user_reply_no", user_reply_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "replyUpdateView.jsp";
	}

	@RequestMapping(value = "/replyUpdate.do", method = RequestMethod.POST)
	public String replyUpdate(HttpServletRequest req, Model mv, ReplyVO rvo, @RequestParam (value = "user_reply_no", required = false)int user_reply_no) throws Exception {
		
		try {
			replyService.updateReply(rvo);
			System.out.println(rvo.getBoard_no());
			mv.addAttribute("user_reply", rvo.getUser_reply());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/getBoard.do?board_no="+rvo.getBoard_no();
	}

}
