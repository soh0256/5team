package com.springbook.biz.user;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import lombok.Generated;
import lombok.Getter;
import lombok.Setter;


@XmlAccessorType(XmlAccessType.FIELD)
public class FileVO {
	
	@Getter @Setter
	private int file_Idx;
	@Getter @Setter
	private String id;
	@Getter @Setter
    private String origin_file_name;
	
    private String file_name;
    private String file_path;
    

	@Override
	public String toString() {
		return "FileVO [file_Idx=" + file_Idx + ", id=" + id + ", origin_file_name=" + origin_file_name
				+ ", file_name=" + file_name + ", file_path=" + file_path + "]";
	}


	public String getFile_name() {
		return file_name;
	}


	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}


	public String getFile_path() {
		return file_path;
	}


	public void setFile_path(String file_path) {
		this.file_path = file_path;
	}
    
}