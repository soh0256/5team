package com.springbook.biz.movie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

@Service
public class MoviesService {

	private static String clientID = "LoTlgXs2Z2EHAxHgEdgO";
	private static String clientSecret = "nrwRFOn6SS";

	// display ==> 紐�媛� 異���
	// start==>紐�踰�夷곕��� (item)
	public List<MovieSearchVO> searchMovie(String keyword, int display, int start) {
		// public List<MovieSearchVO> searchMovie(String keyword, int display, int
		// start){
		List<MovieSearchVO> list = null;
		try {

			URL url;
			url = new URL(
					"https://openapi.naver.com/v1/search/" + "movie.xml?query=" + URLEncoder.encode(keyword, "UTF-8")
							+ (display != 0 ? "&display=" + display : "") + (start != 0 ? "&start=" + start : ""));

			URLConnection urlConn = url.openConnection();
			urlConn.setRequestProperty("X-Naver-Client-Id", clientID);
			urlConn.setRequestProperty("X-Naver-Client-Secret", clientSecret);

			BufferedReader br = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
			
			String data = "";
			String msg = null;
			while ((msg = br.readLine()) != null) {
				data += msg;
			}


			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = factory.newPullParser();
			parser.setInput(new StringReader(data));
			// Test���� ���� 諛⑹���� DOM諛⑹���닿린��臾몄��?

			int eventType = parser.getEventType();
			MovieSearchVO vo = null;
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.END_DOCUMENT: // 臾몄���� ��
					break;
				case XmlPullParser.START_DOCUMENT:
					list = new ArrayList<MovieSearchVO>();
					break;
				case XmlPullParser.END_TAG: {
					String tag = parser.getName();
					if (tag.equals("item")) {
						list.add(vo);
					}
					break;
				}

				case XmlPullParser.START_TAG: {
					String tag = parser.getName();
					switch (tag) {
					case "item":
						vo = new MovieSearchVO();
						break;
					case "title":
						if (vo != null)
							vo.setTitle(parser.nextText());
						//System.out.println(vo.getTitle());
						break;
					case "link":
						if (vo != null)
							vo.setLink(parser.nextText());
						//System.out.println(vo.getLink());
						break;
					case "image":
						if (vo != null)
							vo.setImage(parser.nextText());
						//System.out.println(vo.getImage());
						break;
					case "subtitle":
						if (vo != null)
							vo.setSubtitle(parser.nextText());
						//System.out.println(vo.getSubtitle());
						break;
					case "pubDate":
						if (vo != null)
							vo.setPubDate(parser.nextText());
						//System.out.println(vo.getPubDate());
						break;
					case "director;":
						if (vo != null)
							vo.setDirector(parser.nextText());
						//System.out.println(vo.getDirector());
						break;
					case "actor":
						if (vo != null)
							vo.setActor(parser.nextText());
						//System.out.println(vo.getActor());
						break;
					case "userRating":
						if (vo != null)
							vo.setUserRating(parser.next());
						//System.out.println(vo.getUserRating());
						break;
					}

				}
				}
				eventType = parser.next();
			}
//			System.out.println(vo);// �ш린�� 寃����� 紐⑤�� ����媛� 異��μ�� ������ 留�吏�留� list 異��μ������ ����.

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println(list);// �대�몄� ����
//		System.out.println(list.size());
		return list;
	}
	
	public String topMovie(String keyword) {
		
		String text = null;
        try {
            text = URLEncoder.encode(keyword, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("검색어 인코딩 실패",e);
        }


        String apiURL = "https://openapi.naver.com/v1/search/movie.json?query=" + text;    // json 결과
        //String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query="+ text; // xml 결과


        Map<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put("X-Naver-Client-Id", clientID);
        requestHeaders.put("X-Naver-Client-Secret", clientSecret);
        String responseBody = get(apiURL,requestHeaders);

        System.out.println(responseBody);
        
        return responseBody;
	}
	
	 private static String get(String apiUrl, Map<String, String> requestHeaders){
	        HttpURLConnection con = connect(apiUrl);
	        try {
	            con.setRequestMethod("GET");
	            for(Map.Entry<String, String> header :requestHeaders.entrySet()) {
	                con.setRequestProperty(header.getKey(), header.getValue());
	            }


	            int responseCode = con.getResponseCode();
	            if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 호출
	                return readBody(con.getInputStream());
	            } else { // 에러 발생
	                return readBody(con.getErrorStream());
	            }
	        } catch (IOException e) {
	            throw new RuntimeException("API 요청과 응답 실패", e);
	        } finally {
	            con.disconnect();
	        }
	    }


	    private static HttpURLConnection connect(String apiUrl){
	        try {
	            URL url = new URL(apiUrl);
	            return (HttpURLConnection)url.openConnection();
	        } catch (MalformedURLException e) {
	            throw new RuntimeException("API URL이 잘못되었습니다. : " + apiUrl, e);
	        } catch (IOException e) {
	            throw new RuntimeException("연결이 실패했습니다. : " + apiUrl, e);
	        }
	    }


	    private static String readBody(InputStream body){
	        InputStreamReader streamReader = new InputStreamReader(body);


	        try (BufferedReader lineReader = new BufferedReader(streamReader)) {
	            StringBuilder responseBody = new StringBuilder();


	            String line;
	            while ((line = lineReader.readLine()) != null) {
	                responseBody.append(line);
	            }

	            return responseBody.toString();
	        } catch (IOException e) {
	            throw new RuntimeException("API 응답을 읽는데 실패했습니다.", e);
	        }
	    }

}
