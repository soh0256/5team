package com.springbook.biz.reply;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

//VO(Value Object)
@Getter @Setter
public class ReplyVO {
	private String board_no;	// �Խñ� ��ȣ
	private String id;			// �����ڵ�
	private String user_reply_no;	// ����Ϸù�ȣ
	private String user_reply;	// ��۳���
	private Date reply_date;	// ��۳�¥
	
	@Override
	public String toString() {
		return "ReplyVO [board_no=" + board_no + ", id=" + id + ", user_reply_no=" 
				+ user_reply_no + ", user_reply=" + user_reply + ", reply_date="
					+ reply_date + "]";
	}


}