package com.springbook.biz.reply.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.reply.ReplyVO;

@Repository
public class ReplyDAOMybatis{
	
	@Autowired
	private SqlSessionTemplate mybatis;

	// ��� �ۼ�
	// ReplyDAO : reply-mapping.xml���� namespace
	// .insertReply : reply-mapping.xml���� id��
	public void insertReply(ReplyVO vo) {
		mybatis.insert("ReplyDAO.insertReply", vo); 
	}
	
	public List<ReplyVO> selectReply(int board_no) {
		return mybatis.selectList("ReplyDAO.replyList", board_no);
	}

}