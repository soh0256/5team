package com.springbook.view.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.reply.ReplyService;
import com.springbook.biz.reply.ReplyVO;

@Controller
@SessionAttributes("reply") // � url�� �����ؾ� ReplyController�� ������ �� �ִ��� ����
public class ReplyController {
	@Autowired
	private ReplyService replyService;
	
	// ��� ���
	@RequestMapping(value = "/insertReply.do")
	public String insertReply(ReplyVO vo) {
		replyService.insertReply(vo);
		return "redirect:/getBoard.do?board_no=" + vo.getBoard_no();
	}
	
//	@RequestMapping("/replyList.do")
//	public String replyList(ReplyVO vo, Model model) {
//		// Model ���� ����
//		model.addAttribute("replyList", replyService.replyList(vo));
//		return "getBoardList.jsp"; // View �̸� ����
//	}

}
