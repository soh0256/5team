package com.springbook.biz.board.impl;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbook.biz.board.BoardCntVO;
import com.springbook.biz.board.BoardVO;
import com.springbook.biz.notice.NoticeVO;

@Repository
public class BoardDAOMybatis{
	
	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertBoard(BoardVO vo) {
		System.out.println("===> Mybatis insertBoard() �몄�");
		mybatis.insert("BoardDAO.insertBoard", vo);
	}

	public void updateBoard(BoardVO vo) {
		System.out.println("===> Mybatis updateBoard() �몄�");
		mybatis.update("BoardDAO.updateBoard", vo);
	}

	public void deleteBoard(BoardVO vo) {
		System.out.println("===> Mybatis deleteBoard() �몄�");
		mybatis.delete("BoardDAO.deleteBoard", vo);
	}

	public BoardVO getBoard(BoardVO vo) {
		System.out.println("===> Mybatis getBoard() �몄�");
		return (BoardVO) mybatis.selectOne("BoardDAO.getBoard", vo);
	}

	public List<BoardVO> getBoardList(BoardVO vo) {
		System.out.println("===> Mybatis getBoardList() �몄�");
		return mybatis.selectList("BoardDAO.getBoardList", vo);
	}
	
	public void viewCount(BoardVO vo) {
		System.out.println("===> Mybatis viewCount() �몄�");
		mybatis.update("BoardDAO.viewCount", vo);
	}
	
	// 좋아요
	public void insertBoardCnt(BoardCntVO vo) {
		mybatis.insert("BoardCntDAO.insertBoardCnt", vo);
	}

	public void updateBoardCnt(BoardCntVO vo) {
		mybatis.update("BoardCntDAO.updateBoardCnt", vo);
	}
	public void downBoardCnt(BoardCntVO vo) {
		mybatis.update("BoardCntDAO.downBoardCnt", vo);
	}

	public int selectBoardCnt(BoardCntVO vo) {
		return mybatis.selectOne("BoardCntDAO.selectBoardCnt", vo);
	}

	public void deleteBoardCnt(BoardCntVO vo) {
		mybatis.delete("BoardCntDAO.deleteBoardCnt", vo);
	}

	public int saveBoardCnt(BoardCntVO vo) {
		return mybatis.selectOne("BoardCntDAO.saveBoardCnt", vo);
	}

	public int sumBoardCnt(int boad_no) {
		return mybatis.selectOne("BoardCntDAO.sumBoardCnt", boad_no);
	}

	// 싫어요
	public void insertBoardBcnt(BoardCntVO vo) {
		mybatis.insert("BoardCntDAO.insertBoardBcnt", vo);
	}

	public void updateBoardBcnt(BoardCntVO vo) {
		mybatis.update("BoardCntDAO.updateBoardBcnt", vo);
	}

	public void downBoardBcnt(BoardCntVO vo) {
		mybatis.update("BoardCntDAO.downBoardBcnt", vo);
	}

	public int saveBoardBcnt(BoardCntVO vo) {
		return mybatis.selectOne("BoardCntDAO.saveBoardBcnt", vo);
	}

	public void deleteBoardBcnt(BoardCntVO vo) {
		mybatis.delete("BoardCntDAO.deleteBoardBcnt", vo);
	}

	public int sumBoardBcnt(int boad_no) {
		return mybatis.selectOne("BoardCntDAO.sumBoardBcnt", boad_no);
	}
	
	public List<Map<String, String>> boardList(Map<String, String> menuParam) {
		return mybatis.selectList("BoardDAO.boardList", menuParam);
	}
}