package com.springbook.biz.movie;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data @Getter @Setter
public class MoviesResponseDto {
	private int display;
	private Item[] itmes;
	
	@Data
	static class Item{
		public String title;
		public String link;
		public String image;
		public String subtitle;
		public Date pubDate;
		public String director;
		public String actor;
		public float userRating;
		
	}
	
}
