package com.springbook.biz.movie;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/*@RequiredArgsConstructor
 NonNull이나 final이 붙은 필드에 대한 생성자를 생성, 특히 의존성이 많아지는 경우 @RequiredArgsConstructor로 간결한 Constructor Injection 가능 */
/*해당 클래스를 루트 컨테이너 빈(Bean) 객체로 생성해주는 어노테이션*/
@Service
public class MoviesService {

	public MoviesService() {
		this.movieApiClient = new MovieApiClient();}
	
	private final MovieApiClient movieApiClient;
	
	@Transactional(readOnly = true)
	public MoviesResponseDto findByKeyword(String keyword) {
		return movieApiClient.requestMovie(keyword);
	}
	
}
