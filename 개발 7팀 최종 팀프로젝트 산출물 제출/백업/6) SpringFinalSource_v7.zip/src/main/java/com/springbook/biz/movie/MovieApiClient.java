package com.springbook.biz.movie;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

public class MovieApiClient {
	private final RestTemplate restTemplate = new RestTemplate();//수정 필요
	
	private final String CLIENT_ID = "LoTlgXs2Z2EHAxHgEdgO";
	private final String CLIENT_SECRET = "nrwRFOn6SS";
	
	private final String OpenNaverMovieUrl_getMovies = "https://openapi.naver.com/v1/search/movie.json?query={keyword}";
	
	public MoviesResponseDto requestMovie(String keyword) {
		final HttpHeaders headers = new HttpHeaders();
		headers.set("X-Naver-Client-id", CLIENT_ID);
		headers.set("X-Naver-Client-id",CLIENT_SECRET);
		
		final HttpEntity<String> entity = new HttpEntity<>(headers);
		
		return restTemplate.exchange(OpenNaverMovieUrl_getMovies, HttpMethod.GET, entity, MoviesResponseDto.class, keyword).getBody();
				
	} 

	
}
               