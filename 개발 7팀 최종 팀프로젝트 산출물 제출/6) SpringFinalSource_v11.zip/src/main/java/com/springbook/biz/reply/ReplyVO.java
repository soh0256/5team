package com.springbook.biz.reply;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

//VO(Value Object)
public class ReplyVO {
	private String board_no;	// �Խñ� ��ȣ
	private String id;			// �����ڵ�
	private int user_reply_no;	// ����Ϸù�ȣ
	private String user_reply;	// ��۳���
	private Date reply_date;	// ��۳�¥
	private Number gcnt;		// ���ƿ�
	private Number bcnt;		// �Ⱦ��
	
	public String getBoard_no() {
		return board_no;
	}

	public void setBoard_no(String board_no) {
		this.board_no = board_no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getUser_reply_no() {
		return user_reply_no;
	}

	public void setUser_reply_no(int user_reply_no) {
		this.user_reply_no = user_reply_no;
	}

	public String getUser_reply() {
		return user_reply;
	}

	public void setUser_reply(String user_reply) {
		this.user_reply = user_reply;
	}

	public Date getReply_date() {
		return reply_date;
	}

	public void setReply_date(Date reply_date) {
		this.reply_date = reply_date;
	}

	public Number getGcnt() {
		return gcnt;
	}

	public void setGcnt(Number gcnt) {
		this.gcnt = gcnt;
	}

	public Number getBcnt() {
		return bcnt;
	}

	public void setBcnt(Number bcnt) {
		this.bcnt = bcnt;
	}

	@Override
	public String toString() {
		return "ReplyVO [board_no=" + board_no + ", id=" + id + ", user_reply_no=" 
				+ user_reply_no + ", user_reply=" + user_reply + ", reply_date="
					+ reply_date + ", gcnt=" + gcnt + ", bcnt=" + bcnt + "]";
	}


}