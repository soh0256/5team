package com.springbook.view.board;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springbook.biz.board.BoardListVO;
import com.springbook.biz.board.BoardVO;
import com.springbook.biz.movie.MovieSearchVO;
import com.springbook.biz.movie.MoviesService;
import com.springbook.biz.user.UserVO;

@Controller
public class MovieSearchController {
	
	@Autowired 
	private MoviesService service;

	@RequestMapping("movieSearch.do")
	public String movieSearch(@RequestParam(required=false)String keyword, Model model) {
		
		try {
			if(keyword != null) {
				List<MovieSearchVO> list = service.searchMovie(keyword, 10, 1);
				System.out.println(list.size());
				model.addAttribute("movieSearch", list);
				return "movieSearch.jsp";
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return "movieSearch.jsp";
	}
	
	@ResponseBody
	@RequestMapping(value="topMovie.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String topMovie (@RequestParam(defaultValue = "")String keyword, HttpServletResponse response) throws IOException {

		return service.topMovie(keyword);
	}
	
	
//	public ModelAndView movieSearch(@RequestParam(required = false)String keyword) {
//		ModelAndView mav = new ModelAndView();
//		try {
//			if(keyword != null){
//				mav.addObject("movieSearch", service.searchMovie(keyword, 10, 1));
//			}
//				mav.setViewName("movieSearch.jsp");
//			
//				return mav;
//	} catch(Exception e) {
//		e.printStackTrace();
//		return null;
//	}
		
	}
	
		
	
