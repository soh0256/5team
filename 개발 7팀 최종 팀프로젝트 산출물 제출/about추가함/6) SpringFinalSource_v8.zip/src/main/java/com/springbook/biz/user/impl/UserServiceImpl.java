package com.springbook.biz.user.impl;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.springbook.biz.common.Constants;
import com.springbook.biz.user.FileVO;
import com.springbook.biz.user.UserService;
import com.springbook.biz.user.UserVO;

@Service("userService")
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private FileDAOMybatis fileDAO;
	
	public UserVO getUser(UserVO vo) {
		return userDAO.getUser(vo);
	}
	
	@Override
	public void insertUser(MultipartFile file, UserVO vo) throws IllegalStateException, IOException {
		userDAO.insertUser(vo); //일단 이미지 없이 저장
	}


	@Override
	public void deleteUser(UserVO vo) {
		userDAO.deleteUser(vo);
	}

	@Override
	public void insertFile(FileVO vo) throws Exception {
		fileDAO.insertFile(vo);
	}
	
	public FileVO getFile(FileVO vo) {
		return  fileDAO.getFile(vo);
	}

	@Override
	public void modifyUser(MultipartFile file, UserVO vo) {
		// TODO Auto-generated method stub
		
	}
	
}