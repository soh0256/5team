package com.springbook.biz.user;

import org.springframework.web.multipart.MultipartFile;

public interface UserService {
	// CRUD 기능의 메소드 구현
	// 회원 등록
	public UserVO getUser(UserVO vo);
	
	void insertUser(MultipartFile file ,UserVO vo) throws Exception;
	
	void insertFile(FileVO vo) throws Exception;
	
	void modifyUser(MultipartFile file, UserVO vo);
	
	void deleteUser(UserVO vo);
	
	FileVO getFile(FileVO vo) throws Exception;
}
