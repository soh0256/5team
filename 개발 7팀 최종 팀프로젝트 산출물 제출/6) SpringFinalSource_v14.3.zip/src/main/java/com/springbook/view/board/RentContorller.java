package com.springbook.view.board;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.springbook.biz.rent.RentService;
import com.springbook.biz.rent.RentVO;

@Controller
public class RentContorller {

	@Autowired
	RentService rentService;

	@RequestMapping(value = "/rent.do")
	public String List(RentVO vo) {

		return "getRentList.do";
	}

	@RequestMapping(value = "/getRentList.do")
	public String getRentList(RentVO vo, Model mv) {

		try {
			rentService.getRentList(vo);
			mv.addAttribute("rentList", rentService.getRentList(vo));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "getRentList.jsp";
	}

	@RequestMapping(value = "/getRent.do")
	public String getRent(RentVO vo, Model mv, @RequestParam("rent_bno") int rent_bno, HttpSession session) {
		try {
			mv.addAttribute("rent", rentService.getRent(rent_bno));
			mv.addAttribute("fv", rentService.getRent(rent_bno).getRent_file());
			System.out.println("file ��� �ҷ����°�  Ȯ�� = " + rentService.getRent(rent_bno).getRent_file());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Rent �Խù� �������� ����");
		}
		return "getRent.jsp";
	}

	@RequestMapping(value = "/insertRent.do")
	public String insertRent(RentVO vo, Model mv, HttpServletRequest request) throws IOException {
		try {

			// ���� ���ε�
			String fileName = null;
			MultipartFile uploadFile = vo.getUploadFile();
			if (!uploadFile.isEmpty()) {
				String originalFileName = uploadFile.getOriginalFilename();
				System.out.println("originalFileName ===== " + originalFileName);
				String ext = FilenameUtils.getExtension(originalFileName);
				System.out.println("ext ===== " + ext);
				UUID uuid = UUID.randomUUID();
				System.out.println("uuid === " + uuid);

				fileName = uuid.toString() + "." + ext;
				System.out.println(" fileName === " + fileName);

				// String savePath = Constants.getUploadImagesPath();

				ServletContext rootpath = request.getSession().getServletContext();
				System.out.println("rootpath ======" + rootpath);
				String basePath = rootpath.getRealPath("/saveImage");
				System.out.println("basePath ======" + basePath);
				// .exists() ��ο� �����ϴ��� Ȯ�� ��, ���� ���� �ʴ´ٸ�
				if (!new File(basePath).exists()) {
					try {
						// �� ������ ����� savePath��
						new File(basePath).mkdir();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				// ���� ��� �� = ������Ʈ ��� + ������ + ���� �̸�(uuid�� �������� �̸�)
				String filePath = basePath + File.separator + fileName;
				System.out.println("filePath === " + filePath);

				// upload������ filePath������ ���Ӱ� ������ �����Ѵ�.
				uploadFile.transferTo(new File(filePath));

				vo.setRent_file(fileName);

			}
			rentService.intsertRent(vo);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("insertRent ����");
		}
		return "getRentList.do";
	}

	@RequestMapping(value = "/deleteRent.do")
	public String deleteRent(@RequestParam("rent_bno") int rent_bno) {
		try {
			rentService.deleteRent(rent_bno);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Rent�Խù� ���� ����");
		}

		return "getRentList.do";
	}

	@RequestMapping(value = "/updateRentView.do", method = RequestMethod.GET)
	public String updateRentView(@RequestParam("rent_bno") int rent_bno, RentVO vo, Model mv) {
		try {
			mv.addAttribute("rent", rentService.getRent(rent_bno));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("���� ȭ�� �ҷ����� ����");
		}
		return "updateRentView.jsp";
	}

	@RequestMapping(value = "/updateRent.do", method = RequestMethod.POST)
	public String updateRent(@RequestParam(value = "rent_bno", required = false) int rent_bno, RentVO vo, Model mv) {
		try {
			mv.addAttribute("rent", rentService.getRent(rent_bno));
			rentService.updateRent(vo);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Rent �Խñ� ���� ����");
		}
		return "/getRent.do?rent_bno=" + vo.getRent_bno();
	}

	public String uploadFile(File file, RentVO vo) {

		return null;
	}

}
