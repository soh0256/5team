package com.springbook.biz.rent.impl;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbook.biz.rent.RentVO;

@Repository
public class RentDAOMybatis {
	
	@Autowired
	SqlSessionTemplate mybatis;

	public void insertRent(RentVO vo) {
		mybatis.insert("RentDAO.insertRent", vo);
	}
	
	public List<RentVO> getRentList(RentVO vo) {
		return mybatis.selectList("RentDAO.getRentList", vo);
	}
	
	public RentVO getRent(int rent_bno) {
		return mybatis.selectOne("RentDAO.getRent", rent_bno);
	}
	
	public void deleteRent(int rent_bno) {
		mybatis.delete("RentDAO.deleteRent", rent_bno);
	}
	
	public void updateRent(RentVO vo) {
		mybatis.update("RentDAO.updateRent", vo);
	}
	
	
}

