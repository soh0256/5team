package com.springbook.biz.rent;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public interface RentService {

	public void intsertRent(RentVO vo) throws IOException;

	public void deleteRent(int rent_bno);

	public void updateRent(RentVO vo);

	public List<RentVO> getRentList(RentVO vo) throws Exception;

	public RentVO getRent(int rent_bno) throws Exception;
	
	public MultipartFile getFile(int fno) throws Exception;
	
}
