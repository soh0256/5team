package com.springbook.biz.board.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.board.BoardCntVO;
import com.springbook.biz.board.BoardService;
import com.springbook.biz.board.BoardVO;
import com.springbook.biz.notice.NoticeVO;

@Service("boardService")
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardDAOMybatis boardDAO;

	public void insertBoard(BoardVO vo) {
//		if (vo.getSeq() == 0) {
//			throw new IllegalArgumentException("0�� ���� ����� �� �����ϴ�.");
//		}
		boardDAO.insertBoard(vo);
	}

	public void updateBoard(BoardVO vo) {
		boardDAO.updateBoard(vo);
	}

	public void deleteBoard(BoardVO vo) {
		boardDAO.deleteBoard(vo);
	}

	public BoardVO getBoard(BoardVO vo) {
		return boardDAO.getBoard(vo);
	}

	public List<BoardVO> getBoardList(BoardVO vo) {
		return boardDAO.getBoardList(vo);
	}
	
	public void viewCount(BoardVO vo) {
		boardDAO.viewCount(vo);
	}
	

	// ���ƿ�
	@Override
	public void insertBoardCnt(BoardCntVO vo) {
		boardDAO.insertBoardCnt(vo);
	}

	@Override
	public void updateBoardCnt(BoardCntVO vo) {
		boardDAO.updateBoardCnt(vo);
	}
	@Override
	public void downBoardCnt(BoardCntVO vo) {
		boardDAO.downBoardCnt(vo);
	}

	@Override
	public int selectBoardCnt(BoardCntVO vo) {
		return boardDAO.selectBoardCnt(vo);
	}

	@Override
	public void deleteBoardCnt(BoardCntVO vo) {
		boardDAO.deleteBoardCnt(vo);
	}

	@Override
	public int saveBoardCnt(BoardCntVO vo) {
		return boardDAO.saveBoardCnt(vo);
	}

	@Override
	public int sumBoardCnt(int boad_no) {
		return boardDAO.sumBoardCnt(boad_no);
	}

	// �Ⱦ��
	@Override
	public void insertBoardBcnt(BoardCntVO vo) {
		boardDAO.insertBoardBcnt(vo);
	}

	@Override
	public void updateBoardBcnt(BoardCntVO vo) {
		boardDAO.updateBoardBcnt(vo);
	}
	@Override
	public void downBoardBcnt(BoardCntVO vo) {
		boardDAO.downBoardBcnt(vo);
	}

	@Override
	public int saveBoardBcnt(BoardCntVO vo) {
		return boardDAO.saveBoardBcnt(vo);
	}

	@Override
	public void deleteBoardBcnt(BoardCntVO vo) {
		boardDAO.deleteBoardBcnt(vo);
	}

	@Override
	public int sumBoardBcnt(int boad_no) {
		return boardDAO.sumBoardBcnt(boad_no);
	}

	@Override
	public List<Map<String, String>> boardList(Map<String, String> menuParam) {
		return boardDAO.boardList(menuParam);
	}
	
	@Override
	public int selectBoardListCnt(BoardVO vo) {
		return boardDAO.selectBoardListCnt(vo);
	}
	
}