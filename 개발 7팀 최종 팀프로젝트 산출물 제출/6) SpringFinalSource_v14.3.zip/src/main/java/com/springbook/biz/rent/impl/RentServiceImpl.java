package com.springbook.biz.rent.impl;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.springbook.biz.file.FileUtils;
import com.springbook.biz.rent.RentFileVO;
import com.springbook.biz.rent.RentService;
import com.springbook.biz.rent.RentVO;

@Service
public class RentServiceImpl implements RentService {

	@Autowired
	RentDAOMybatis RentDAO;
	
	@Override
	public void intsertRent(RentVO vo) throws IOException {
		RentDAO.insertRent(vo);

	}

	@Override
	public List<RentVO> getRentList(RentVO vo) {
		return RentDAO.getRentList(vo);
	}

	@Override
	public void deleteRent(int rent_bno) {
		RentDAO.deleteRent(rent_bno);
	}

	@Override
	public void updateRent(RentVO vo) {
		RentDAO.updateRent(vo);
	}

	@Override
	public RentVO getRent(int rent_bno) {
		return RentDAO.getRent(rent_bno);
	}

	@Override
	public MultipartFile getFile(int fno) throws Exception {
		return null;
	}


}
