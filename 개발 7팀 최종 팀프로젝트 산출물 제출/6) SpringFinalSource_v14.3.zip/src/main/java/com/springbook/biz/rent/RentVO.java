package com.springbook.biz.rent;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RentVO {
	
	private int rent_bno;
	private String rent_title;
	private String rent_content;
	private String rent_writer;
	private Date rent_date;
	private int rent_cnt;
	private String rent_file;
	private MultipartFile uploadFile;
	
	
	@Override
	public String toString() {
		return "RentVO Class [rent_bno = " + rent_bno+" ] rent_title = [" + rent_title +"]" + "uploadFile = " + uploadFile + "rent_file = " + rent_file; 
	}
	
}
