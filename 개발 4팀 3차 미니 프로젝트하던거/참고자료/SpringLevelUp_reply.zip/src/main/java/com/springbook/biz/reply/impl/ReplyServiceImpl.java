package com.springbook.biz.reply.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.reply.ReplyService;
import com.springbook.biz.reply.ReplyVO;

@Service("replyService")
public class ReplyServiceImpl implements ReplyService {
	@Autowired
private ReplyDAOMybatis replyDAO;

public ReplyVO getReply(ReplyVO vo) {
	return replyDAO.getReply(vo);
}
public List<ReplyVO> getReplyList(ReplyVO vo) {
	return replyDAO.getReplyList(vo);
}
public void insertReply(ReplyVO vo){
	replyDAO.insertReply(vo);
}
public void updateReply(ReplyVO vo) {
	replyDAO.updateReply(vo);
}
public void deleteReply(ReplyVO vo) {
	replyDAO.deleteReply(vo);
}
}
