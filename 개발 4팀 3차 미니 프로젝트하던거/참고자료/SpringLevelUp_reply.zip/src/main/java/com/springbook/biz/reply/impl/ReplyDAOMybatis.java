package com.springbook.biz.reply.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbook.biz.reply.ReplyVO;

@Repository
public class ReplyDAOMybatis {

	@Autowired
	private SqlSessionTemplate mybatis;
	
	public List<ReplyVO>getReplyList(ReplyVO vo){
		System.out.println("===> Mybatis�� getReplyList() ��� ó��");
		return mybatis.selectList("replyDAO.getReplyList",vo);
	}
	public void insertReply(ReplyVO vo){
		System.out.println("===> Mybatis�� insertReply() ��� ó��");
		mybatis.insert("replyDAO.insertReply", vo);
	}
	public void updateReply(ReplyVO vo){
		System.out.println("===> Mybatis�� updateReply() ��� ó��");
		mybatis.update("replyDAO.updateReply", vo);
	}
	public void deleteReply(ReplyVO vo){
		System.out.println("===> Mybatis�� deleteReply() ��� ó��");
		mybatis.delete("replyDAO.deleteReply", vo);
	}
	public ReplyVO getReply(ReplyVO vo) {
		System.out.println("===> Mybatis�� getReply() ��� ó��");
		return mybatis.selectOne("replyDAO.getReply", vo);
	}
}
