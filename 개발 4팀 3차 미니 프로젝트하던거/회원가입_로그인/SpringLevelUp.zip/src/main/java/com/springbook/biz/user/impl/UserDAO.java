package com.springbook.biz.user.impl;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.springbook.biz.user.UserVO;

// DAO(Data Access Object)
@Repository("UserDAO")
public class UserDAO {
	
	@Autowired
	private SqlSessionTemplate mybatis;
	
	public void insertUser(UserVO vo) {
		System.out.println("===> UserDao�� insertUser() ȣ��");
		mybatis.insert("UserDAO.insertUser", vo);
	}
	
	public UserVO getUser(UserVO vo) {
		System.out.println("===> UserDao�� getUser() ȣ��");
		return mybatis.selectOne("UserDAO.getUser", vo);
		
	}
	
}