package com.example.manager.ui.boardInsert;

import android.telecom.Call;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.model.Board;
import com.example.manager.repository.BoardRepository;

import java.io.File;
import java.util.Date;

import retrofit2.Callback;

public class BoardInsertViewModel extends ViewModel {

    private final BoardRepository repository;

//    public MutableLiveData<String> no;
    public MutableLiveData<String> id;
    public MutableLiveData<String> title;
    public MutableLiveData<String> contents;
    public MutableLiveData<String> dates;
    public MutableLiveData<String> hits;
//    public MutableLiveData<String> image;

    public BoardInsertViewModel(BoardRepository repository) {
        this.repository = repository;
        id = new MutableLiveData<>();
        title = new MutableLiveData<>();
        contents = new MutableLiveData<>();
        dates = new MutableLiveData<>();
        hits = new MutableLiveData<>();
//        image = new MutableLiveData<>();
    }

    void insertBoard(Callback<Void> callback){
        Board board = new Board(
                id.getValue(),
                title.getValue(),
                contents.getValue(),
                dates.getValue(),
                hits.getValue()
        );

//        File file = new File(image.getValue());
        repository.insertBoard(board, callback);

    }
}