package com.example.manager.ui.boardInsert;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.features.ReturnMode;
import com.example.manager.R;
import com.example.manager.databinding.FragmentInsertBoardBinding;
import com.example.manager.ui.base.ViewModelFactory;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BoardInsertFragment extends Fragment {
    private static final int PERMISSION_REQUEST_CODE = 1000;

    private ImageView image;

    private FragmentInsertBoardBinding binding;
    private BoardInsertViewModel boardInsertViewModel;

    private Context context;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_insert_board, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.context = requireContext().getApplicationContext();

        // Data Binding 연결
        boardInsertViewModel = new ViewModelProvider(this, new ViewModelFactory()).get(BoardInsertViewModel.class);
        binding.setVm(boardInsertViewModel);

        image = view.findViewById(R.id.board_image_view);
        final ImageView addImageView = view.findViewById(R.id.add_board_image_view);

        // 게시판 사진 등록 이벤트 처리
        addImageView.setOnClickListener(v -> {
            checkAndRequestPermissionImage();

            // 기기에서 이미지 가져오기
            ImagePicker.create(this)
                    .returnMode(ReturnMode.GALLERY_ONLY)
                    .includeVideo(false)
                    .includeAnimation(false)
                    .single()
                    .limit(1)
                    .imageDirectory("Camera")
                    .start();
        });

        // 게시글 쓰기 버튼 클릭시
        final Button insertBoardButton = view.findViewById(R.id.board_insert_btn);

        insertBoardButton.setOnClickListener(v -> {
            boardInsertViewModel.insertBoard(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if(response.isSuccessful()){
                        Toast.makeText(context, "게시글 쓰기 성공", Toast.LENGTH_SHORT).show();
                        // 이전 화면으로 돌아가기
                        requireActivity().onBackPressed();
                    }else{
                        Toast.makeText(context, "게시글 쓰기 실패", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Toast.makeText(context, "게시글 쓰기 실패", Toast.LENGTH_SHORT).show();
                }
            });
        });

    }



    private void checkAndRequestPermissionImage() {
        if (requireActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[] { Manifest.permission.READ_EXTERNAL_STORAGE },
                    PERMISSION_REQUEST_CODE
            );
        }
    }
}