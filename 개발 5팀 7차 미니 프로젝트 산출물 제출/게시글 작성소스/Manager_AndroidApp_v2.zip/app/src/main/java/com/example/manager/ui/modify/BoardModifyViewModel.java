package com.example.manager.ui.modify;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.model.Board;
import com.example.manager.repository.BoardRepository;

import java.io.File;

import retrofit2.Callback;

public class BoardModifyViewModel extends ViewModel {

    private final BoardRepository repository;
//    public MutableLiveData<String> no;
    public MutableLiveData<String> id;
    public MutableLiveData<String> title;
    public MutableLiveData<String> contents;
    public MutableLiveData<String> dates;
//    public MutableLiveData<String> hits;
//    public MutableLiveData<String> image;
    private String initimage;

    public BoardModifyViewModel(BoardRepository repository) {
        this.repository = repository;
        id=new MutableLiveData<>();
        title=new MutableLiveData<>();
        contents=new MutableLiveData<>();
        dates=new MutableLiveData<>();
//        hits=new MutableLiveData<>();
//        image=new MutableLiveData<>();
    }
    /**
     * 수정할 글 데이터로 초기화
     */
    void initBoardData(Board board){
        id.setValue(board.getId());
        title.setValue(board.getTitle());
        contents.setValue(board.getContents());
//        image.setValue(board.getImage());
        initimage=board.getImage();
    }

    /**
     * 글 정보 수정 요청
     */

    void boardmodify(Callback<Void> callback){
        Board board=new Board(
                id.getValue(),
                title.getValue(),
                contents.getValue(),
                dates.getValue()
        );
//        if(board.getImage().equals(initimage)){
            repository.modifyBoard(board,callback);
//        } else {
//            File file=new File(image.getValue());
//            repository.modifyBoard(board,file,callback);
//        }
    }

    /**
     * 비어있는 정보(id와 제목)가 있는지 검사
     */
    boolean validateModifyInfo(){
        return validateIdAndTitle();
    }

    boolean validateIdAndTitle() {
        return id.getValue() != null
                && !id.getValue().contains(" ")
                && title.getValue() != null
                && !title.getValue().contains(" ");
    }

}