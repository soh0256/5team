package com.example.manager.network;



import com.example.manager.model.Board;
import com.example.manager.model.LoginInfo;
import com.example.manager.model.Member;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface BoardService {

    @GET("board")
    Call<List<Board>> getAllBoards();

    @GET("board/{title}")
    Call<Board> findBoardByTitle(@Path("title") String title);

    @GET("board/{contents}")
    Call<Board> findBoardByContents(@Path("contents") String contents);

    @GET("board/readBoard")
    Call<Board> getBoard(Board board);

    @Multipart
    @POST("board/insert")
    Call<Void> insertBoard(@Part("board") Board board);

    @PUT("board/modify")
    Call<Void> modifyBoard(@Body Board board);

    @Multipart
    @POST("board/modify-image")
    Call<Void> modifyBoardWithimage(@Part("board") Board board, @Part MultipartBody.Part image);

    @DELETE("board")
    Call<Void> deleteBoard(@Body Board board);

}
