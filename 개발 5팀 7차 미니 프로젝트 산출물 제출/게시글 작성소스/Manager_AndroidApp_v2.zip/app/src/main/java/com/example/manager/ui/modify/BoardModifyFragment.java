package com.example.manager.ui.modify;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.features.ReturnMode;
import com.esafirm.imagepicker.model.Image;
import com.example.manager.R;
import com.example.manager.databinding.FragmentUpdateBoardBindingImpl;
import com.example.manager.model.Board;
import com.example.manager.ui.base.ViewModelFactory;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BoardModifyFragment extends Fragment {
    private static final int PERMISSION_REQUEST_CODE = 1000;
    private ImageView boardView;
    private FragmentUpdateBoardBindingImpl binding;
    private BoardModifyViewModel boardModifyViewModel;
    private Board board;
    private Context context;
    public BoardModifyFragment(Board board){
        super();
        this.board=board;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding= DataBindingUtil.inflate(inflater, R.layout.fragment_update_board,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context=requireActivity().getApplicationContext();
        //Data Binding연결
        boardModifyViewModel=new ViewModelProvider(this,new ViewModelFactory()).get(BoardModifyViewModel.class);
        boardModifyViewModel.initBoardData(board);
        binding.setVm(boardModifyViewModel);
        boardView=view.findViewById(R.id.board_image_view);
        final ImageView addImageView=view.findViewById(R.id.add_board_image_view);
        addImageView.setOnClickListener(v->{
            checkAndRequestPermission();
            ImagePicker.create(this)
                    .returnMode(ReturnMode.GALLERY_ONLY)
                    .includeVideo(false)
                    .includeAnimation(false)
                    .single()
                    .limit(1)
                    .imageDirectory("Camera")
                    .start();
        });
        final Button boardModifyButton=view.findViewById(R.id.board_insert_btn);
        boardModifyButton.setOnClickListener(v->{
            if(!boardModifyViewModel.validateIdAndTitle()){
                Toast.makeText(context,"아이디나 제목을 공백으로 포함 할수 없습니다.",Toast.LENGTH_SHORT).show();
                return;
            }
            if(!boardModifyViewModel.validateModifyInfo()){
                Toast.makeText(context,"빈 칸을 채우세요",Toast.LENGTH_SHORT).show();
                return;
            }
            //회원 정보 수정요청
            boardModifyViewModel.boardmodify(new Callback<Void>(){
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()){
                        Toast.makeText(context,"글 수정 성공",Toast.LENGTH_SHORT).show();
                        requireActivity().onBackPressed();
                    }else {
                        Toast.makeText(context,"글 수정 실패",Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Toast.makeText(context,"글 수정 실패",Toast.LENGTH_SHORT).show();
                }
            });
        });
        final Button cancelButton = view.findViewById(R.id.board_insert_cancel_btn);
        // 취소 버튼 클릭 이벤트 처리
        cancelButton.setOnClickListener(v -> {
            // 이전 화면으로 돌아가기
            requireActivity().onBackPressed();
        });
//        boardModifyViewModel.image.observe(getViewLifecycleOwner(),url->{
//            Glide.with(requireContext())
//                    .load(url)
//                    .apply(new RequestOptions().circleCrop())
//                    .into(boardView);
//        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(ImagePicker.shouldHandle(requestCode,resultCode,data)){
            Image image=ImagePicker.getFirstImageOrNull(data);
            if(image!=null){
                boardModifyViewModel.image.setValue(image.getPath());
            }
        }
        super.onActivityResult(requestCode,resultCode,data);
    }

    /**
     * 저장소 접근 권한 확인 및 요청
     */
    private void checkAndRequestPermission() {
        if (requireActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[] { Manifest.permission.READ_EXTERNAL_STORAGE },
                    PERMISSION_REQUEST_CODE
            );
        }
    }
}