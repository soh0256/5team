-- 초기 샘플 데이터 생성
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample1', 'password1', '홍길동', 'abc123@naver.com', '01012345678', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample2', 'password2', '철수', 'abc456@naver.com', '01034567890', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample3', 'password3', '영희', 'abc789@naver.com', '01023456789', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample4', 'password4', '짱구', 'def123@naver.com', '01015324687', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample5', 'password5', '맹구', 'def456@naver.com', '01045887954', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample6', 'password6', '코난', 'def789@naver.com', '01011354687', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample7', 'password7', '남도일', 'zxc123@naver.com', '01044968879', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample8', 'password8', '진구', 'zxc456@naver.com', '01033415467', '');
insert into MEMBER(id, password, name, email, phone_number, profile_pic_url) values ('sample9', 'password9', '비실', 'zxc789@naver.com', '01066589775', '');
