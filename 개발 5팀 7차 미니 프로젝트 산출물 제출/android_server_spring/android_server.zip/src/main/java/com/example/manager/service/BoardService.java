package com.example.manager.service;

import java.io.File;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.manager.domain.Board;
import com.example.manager.repository.BoardRepository;

@Service
public class BoardService {
	@Autowired
    private BoardRepository boardRepository;

     //게시판 글 가져오기
	 //모든 게시판의 칼럼 값들을 가져온다고 해도 frontend에선 content만 쓰지 않으면 됨
    public List<Board> getBoardList() {
        return boardRepository.findAll();
    }

    //글 제목과 내용을 통해 원하는 게시글 조회하기 
    //글 제목으로 찾기 //if문으로 바꾼 후 List로 바꿔도 가능
    public Optional<Board> findByTitle(String title){
    	return boardRepository.findByTitle(title);
    }
    //글 내용으로 찾기 
    public Optional<Board> findByContents(String contents){
    	return boardRepository.findByContents(contents);
    }
    
    
    
    //게시글삽입
    public void insertBoard(Board board) {
    	boardRepository.save(board);
    }
   
    
    //게시글 내용보기(해당 게시글을 선택하면, 해당 게시글에 해당되는 제목과 내용 및 작성자 등등이 다 따라오니까 
    //매개변수로 Board를 넣어준다
    public List<Board> getBoard(Board board) {
    	Optional<Board> target = boardRepository.findByNo(board.getNo());
    	if(target.isPresent()) {
    		return boardRepository.findAll();
    	}else {
		return null;
    	}
    }
    
    //게시글 수정
    public void modifyBoard(Board board) {
    	Optional<Board> target = boardRepository.findByNo(board.getNo());
    	if(target.isPresent()) {
    		boardRepository.save(board);
    	}
    }
  
    //게시글 삭제
    public void deleteBoard(Board board) {//여기서 String으로 받는 매개변수 targets는 어디서 받아오는 값인가 
    		int number = board.getNo();
            Optional<Board> target = boardRepository.findByNo(number);
            if (target.isPresent()) {
                // DB 에서 회원 삭제
                boardRepository.deleteAll();
            }    
                
    }

    
    
    private void createDirectory(String path) {
        File directory = new File(path);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }

}
