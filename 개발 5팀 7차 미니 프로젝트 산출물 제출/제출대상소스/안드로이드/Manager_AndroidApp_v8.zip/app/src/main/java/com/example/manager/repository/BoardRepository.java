package com.example.manager.repository;



import com.example.manager.model.Board;
import com.example.manager.model.LoginInfo;
import com.example.manager.network.BoardService;
import com.example.manager.network.MemberService;

import java.io.File;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Callback;

public class BoardRepository {
    private BoardService boardService;
//    private MemberService memberService;

    public BoardRepository(BoardService boardService) {this.boardService = boardService;}

    public void getAllBoards(Callback<List<Board>> callback){
        boardService.getAllBoards().enqueue(callback);
    }

    public void getBoard(Board board, Callback<Board> callback){
        boardService.getBoard(board).enqueue(callback);
    }
    public void insertBoard(Board board, Callback<Void> callback){
//        MultipartBody.Part profileFile = MultipartBody.Part.createFormData(
//                "profilePic",
//                file.getName(),
//                RequestBody.create(MediaType.parse("image/*"), file));

        boardService.insertBoard(board).enqueue(callback);
    }

    public void updateBoard(Board board, Callback<Void> callback){
        boardService.updateBoard(board).enqueue(callback);
    }


    public  void deleteBoard(String targets, Callback<Void> callback){
        boardService.deleteBoard(targets).enqueue(callback);
    }

//    public void modifyBoard(Board board, File file,Callback<Void> callback){
//        MultipartBody.Part image=MultipartBody.Part.createFormData(
//                "image",
//                file.getName(),
//                RequestBody.create(MediaType.parse("image/*"),file));
//        boardService.modifyBoardWithimage(board,image).enqueue(callback);
//    }
}