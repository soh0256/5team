package com.example.manager.ui.boardInsert;

import android.telecom.Call;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.model.Board;
import com.example.manager.model.Member;
import com.example.manager.repository.BoardRepository;

import java.io.File;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import retrofit2.Callback;

public class BoardInsertViewModel extends ViewModel {

    private final BoardRepository repository;

    Date Time = Calendar.getInstance().getTime();
    SimpleDateFormat Date = new SimpleDateFormat("yy-MM-dd", Locale.getDefault());
    String dates;

    public MutableLiveData<String> id;
    public MutableLiveData<String> title;
    public MutableLiveData<String> contents;

    public BoardInsertViewModel(BoardRepository repository) {
        this.repository = repository;
        id = new MutableLiveData<>();
        title = new MutableLiveData<>();
        contents = new MutableLiveData<>();
        dates = Date.format(Time);
    }

    void insertBoard(Callback<Void> callback){
        Board board = new Board(
                id.getValue(),
                title.getValue(),
                contents.getValue(),
                dates = Date.format(Time)
        );

        repository.insertBoard(board, callback);

    }
}