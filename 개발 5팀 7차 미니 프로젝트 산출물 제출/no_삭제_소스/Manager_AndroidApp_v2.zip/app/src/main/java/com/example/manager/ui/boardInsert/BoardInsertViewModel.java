package com.example.manager.ui.boardInsert;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.model.Board;
import com.example.manager.repository.BoardRepository;

import java.io.File;
import java.util.List;

import retrofit2.Callback;

public class BoardInsertViewModel extends ViewModel {
    private final BoardRepository repository;
    public MutableLiveData<Integer> no;
    public MutableLiveData<String> id;
    public MutableLiveData<String> title;
    public MutableLiveData<String> contents;
    public MutableLiveData<String> dates;
    public MutableLiveData<String> hits;
    public MutableLiveData<String> image;

    public BoardInsertViewModel(BoardRepository repository) {
        this.repository = repository;
        id = new MutableLiveData<>();
        title = new MutableLiveData<>();
        contents = new MutableLiveData<>();
        dates = new MutableLiveData<>();
        hits = new MutableLiveData<>();
        image = new MutableLiveData<>();
    }

    void insert(Callback<List <Board>> callback) {
        Board board = new Board(
                id.getValue(),
                title.getValue(),
                contents.getValue(),
                dates.getValue(),
                hits.getValue()
        );

        File file = new File(image.getValue());
        repository.getAllBoards(callback);
    }

    /**
     * 비어있는 정보나 잘못된 입력이 있는지 검사
     */
    boolean validateInsertInfo() {
        return validateId()
                && validateTitle();
    }

    /**
     * 아이디와 이름 유효성 검사
     */
    boolean validateId() {
        return id.getValue() != null
                && !id.getValue().contains(" ");
    }

    boolean validateTitle(){
        return title.getValue() != null
                && !title.getValue().contains(" ");
    }


}