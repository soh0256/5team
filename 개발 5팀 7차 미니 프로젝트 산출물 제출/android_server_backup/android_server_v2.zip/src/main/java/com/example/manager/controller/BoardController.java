package com.example.manager.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.manager.domain.Board;
import com.example.manager.domain.Member;
import com.example.manager.dto.MemberLoginDto;
import com.example.manager.service.BoardService;
import com.example.manager.service.MemberService;

@RestController 
/*Json형태로 객체 데이터를 반환, Spring Boot를 API서버로 사용할 때 혹은 앱 개발시 사용 
Spring MVC Controlle에 @Responsbody가 추가된 것.  
client - http Request -> Dispatcher Servlet -> Handler Mapping -> Rest Controller 
(@Controller + @ResponseBody) -> client */
//Handler Mapping : 해당 요청 정보를 기준으로 어떤 컨트롤러를 사용할 것인가를 결정하는 인터페이스 
@RequestMapping("/board")
public class BoardController {
	@Autowired//
    private BoardService boardService;
	//화면에서 option key값으로 contents, titles
	//화면에서 option value값으로 검색어 입력받기 
	//입력받은 것 dto에 넣어주기 
	/*					<select name="searchCondition">
						<c:forEach items="${conditionMap}" var="option">
							<option value="${option.value}">${option.key}
						</c:forEach>							
					</select> */
	//검색 요청이 들어올 때 해당 요청과 매핑되는 메서드를 따로 구현 
	// 해당 요청이 들어왔을 때 나중에 getBoardList메서드 마지막에 호출
	//검색 부분만 searchBoardList로 할 수 있나...? 요청을?
	//<form action=getBoardList.do method="post"></form>처럼
	@ModelAttribute("conditionMap") //getBoardList요청이 오면 첫 번째로 이거 먼저 호출됨, 나중엔 여기서 생성된 conditonMap과 boardList 모두 사용가능
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new HashMap<String, String>();
		conditionMap.put("제목", "TITLE");
		conditionMap.put("내용", "CONTENT");
		return conditionMap;
	}

	
	
    @PostMapping("/getBoardList")
    public List<Board> getBoardList(@RequestBody Board board, Model model) {
    	//
    	if(board.getSearchCondition()==null)//저 앞의 searchConditionMap과 이 메서드 사이의 과정이 궁금하구먼
    		board.setSearchCondition("TITLE");
    	if(board.getSearchKeyword()==null);
    		board.setSearchKeyword("");
    	model.addAttribute("boardList", boardService.getBoardList(board));
    		return boardService.getBoardList(board); // View 이름 리턴
    }
	
    
    //게시글 상세 내용보기
    @GetMapping("/{no}")
    public List<Board> getBoard(@PathVariable("no") int no, Board board){
    	return boardService.getBoard(board);
    }
    
    //게시글 쓰기
    @PutMapping("/insert")
    public void insertBoard(@RequestBody Board board, @RequestPart("image") MultipartFile file) {
    	boardService.insertBoard(board, file);
    }
    
    //게시글 수정 
    @PutMapping("/update")
    public void updateBoard(@RequestBody Board board) {
    	boardService.updateBoard(board);
    }
    
    //게시글 삭제
    @DeleteMapping("/delete")
    public void deleteBoard(@RequestBody Board board) {
    	boardService.deleteBoard(board);
    }
    
   
}
