package com.example.manager.ui.boardInsert;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.repository.BoardRepository;

import java.util.Date;

public class BoardInsertViewModel extends ViewModel {

    private final BoardRepository repository;

    public MutableLiveData<String> no;
    public MutableLiveData<String> id;
    public MutableLiveData<String> title;
    public MutableLiveData<String> contents;
    public MutableLiveData<String> dates;
    public MutableLiveData<String> hits;
    public MutableLiveData<String> image;

    public BoardInsertViewModel(BoardRepository repository) {
        this.repository = repository;
    }
}