package com.example.manager.repository;



import com.example.manager.model.LoginInfo;
import com.example.manager.model.Member;
import com.example.manager.network.BoardService;
import com.example.manager.network.MemberService;

import java.io.File;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Callback;

public class BoardRepository {
    private BoardService boardService;

}