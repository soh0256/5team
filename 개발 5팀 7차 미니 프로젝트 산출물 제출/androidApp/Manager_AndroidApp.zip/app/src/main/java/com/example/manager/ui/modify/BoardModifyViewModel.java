package com.example.manager.ui.modify;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.repository.BoardRepository;

public class BoardModifyViewModel extends ViewModel {

    private final BoardRepository repository;

    public MutableLiveData<String> no;
    public MutableLiveData<String> id;
    public MutableLiveData<String> title;
    public MutableLiveData<String> contents;
    public MutableLiveData<String> dates;
    public MutableLiveData<String> hits;
    public MutableLiveData<String> image;

    public BoardModifyViewModel(BoardRepository repository) {
        this.repository = repository;
    }
}