package com.example.manager.ui.boardInsert;

import androidx.fragment.app.Fragment;

public class BoardInsertFragment extends Fragment {

}