package com.example.manager.model;

import java.util.Date;

/**
 * 게시판 정보 모델
 */
public class Board {
    private Number no;
    private String id;
    private String title;
    private String contents;
    private Date dates;
    private Number hits;
    private String image;

    public Board(Number no, String id, String title, String contents, Date dates, Number hits) {
        this.no = no;
        this.id = id;
        this.title = title;
        this.contents = contents;
        this.dates = dates;
        this.hits = hits;
    }

    public Number getNo() {
        return no;
    }

    public void setNo(Number no) { this.no = no; }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public Date getDates() { return dates; }

    public void setDates(Date dates) {
        this.dates = dates;
    }

    public Number getHits() {
        return hits;
    }

    public void setHits(Number hits) {
        this.hits = hits;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
