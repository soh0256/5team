package com.example.manager.ui.boardlist;


import androidx.lifecycle.ViewModel;


public class BoardListViewModel extends ViewModel {

}
