package com.example.manager.ui.boardlist;


import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.manager.model.Board;
import com.example.manager.repository.BoardRepository;

import java.util.List;

import retrofit2.Callback;


public class BoardListViewModel extends ViewModel {

    private BoardRepository repository;

    private MutableLiveData<List<Board>> boardList;

    public BoardListViewModel(BoardRepository repository) {
        this.repository = repository;

        boardList = new MutableLiveData<>();
    }

    public MutableLiveData<List<Board>> getBoardList() {return boardList;}

    // 모든 게시글 조회
    void getAllBoards(Callback<List<Board>> callback) {repository.getAllBoards(callback);}

}
