package com.example.manager.ui.boardlist;

import androidx.fragment.app.Fragment;

import com.example.manager.ui.memberlist.SearchDialog;


public class BoardListFragment extends Fragment implements SearchDialog.ResultListener {

    @Override
    public void searchMembersByName(String name) {

    }
}