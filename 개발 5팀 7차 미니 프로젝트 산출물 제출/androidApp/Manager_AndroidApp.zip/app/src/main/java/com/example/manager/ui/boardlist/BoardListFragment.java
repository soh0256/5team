package com.example.manager.ui.boardlist;

import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.example.manager.R;
import com.example.manager.databinding.FragmentBoardListBinding;
import com.example.manager.model.LoginAccount;
import com.example.manager.model.Board;
import com.example.manager.ui.base.MainActivity;
import com.example.manager.ui.base.ViewModelFactory;
import com.example.manager.ui.login.LoginFragment;
import com.example.manager.ui.modify.ModifyFragment;
import com.example.manager.ui.signup.SignUpFragment;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class BoardListFragment extends Fragment {

    private FragmentBoardListBinding board_binding;
    private BoardListViewModel boardListViewModel;

    private BoardListAdapter boardListAdapter;

    private Button boardUpdateButton;
    private Button boardDeleteButton;
    private Button memberSearchButton;
    private Button boardLogoutButton;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        board_binding = DataBindingUtil.inflate(inflater, R.layout.fragment_board_list, container, false);

        return board_binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        boardListViewModel = new ViewModelProvider(this, new ViewModelFactory()).get(BoardListViewModel.class);

        boardUpdateButton = view.findViewById(R.id.board_update_btn); // 게시글 수정
        boardDeleteButton = view.findViewById(R.id.board_delete_btn); // 게시글 삭제
        memberSearchButton = view.findViewById(R.id.member_search_btn); // 회원 리스트 보기
        boardLogoutButton = view.findViewById(R.id.board_Logout_btn); // 로그아웃

        boardListAdapter = new BoardListAdapter();
        RecyclerView recyclerView = view.findViewById(R.id.board_list_recycler_view);
        recyclerView.setAdapter(boardListAdapter);

        // 전체 게시글 조회
        BoardList();

        handleBoardUpdateEvent();
        handleBoardDeleteEvent();
        handleMemberSearchEvent();
        handleBoardLogoutEvent();

    }

    private void BoardList() {
        boardListViewModel.getAllBoards(new Callback<List<Board>>(){
            @Override
            public void onResponse(Call<List<Board>> call, Response<List<Board>> response) {
                if(response.isSuccessful()){
                    // 게시글 조회 성공
                    boardListViewModel.getBoardList().setValue(response.body());
                    // 조회한 게시글 정보 어댑터에 세팅
                    boardListAdapter.setBoardList(boardListViewModel.getBoardList().getValue());
                }else if (requireActivity() != null){
                    Toast.makeText(requireActivity().getApplicationContext(),"게시글 조회 실패", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Board>> call, Throwable t) {
                if (requireActivity() != null) {
                    Toast.makeText(requireActivity().getApplicationContext(), "게시글 조회 실패", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    // 게시글 수정
    private void handleBoardUpdateEvent() {
    }

    // 게시글 삭제
    private void handleBoardDeleteEvent() {
    }

    // 회원리스트 조회
    private void handleMemberSearchEvent() {
    }

    // 로그아웃
    private void handleBoardLogoutEvent() {
    }
}